import json
import logging
import os
from datetime import datetime
from annuity_api import annuity_client
from rabbitmq_manager import rabbitmq_manager
from config import settings

logger = logging.getLogger(__name__)

class MessageProcessor:
    def __init__(self):
        self.processed_count = 0
        self.scraping_success_count = 0
        self.scraping_error_count = 0
        self.api_success_count = 0
        self.api_error_count = 0

    def save_result_to_file(self, result, directory="scrape_results"):
        os.makedirs(directory, exist_ok=True)
        app_no = result.get("applicatioN_NUMBER", "unknown")
        country = result.get("countrY_ISO2_CODE", "XX")
        timestamp = datetime.utcnow().strftime("%Y%m%dT%H%M%S%f")[:-3]
        filename = os.path.join(directory, f"{country}_{app_no}_{timestamp}.json")
        try:
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
            print(f"📁 Saved result locally: {filename}")
        except Exception as e:
            print(f"❌ Error saving to file: {e}")
            logger.error(f"Error writing scrape result to file: {e}")

    async def process_scrape_request(self, message_data):
        try:
            app_no = message_data.get("app_no", "")
            country = message_data.get("country", "")
            template_id = message_data.get("template_id", "")
            
            if not app_no or not country:
                return {"success": False, "error": "Missing data", "input": message_data}

            print(f"🔍 [{datetime.now().strftime('%H:%M:%S')}] STARTING SCRAPE: {app_no} ({country})")
            
            scrape_payload = [{
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "applicatioN_NUMBER": app_no,
                "countrY_ISO2_CODE": country
            }]
            
            from scraper import scrape_data
            results = await scrape_data(scrape_payload)
            result = results[0] if results else {}

            print(f"📊 [{datetime.now().strftime('%H:%M:%S')}] SCRAPE RESULT ANALYSIS for {app_no}:")
            print(f"   📦 Raw result keys: {list(result.keys()) if result else 'EMPTY'}")
            print(f"   🎯 WEB_SCRAPER_STATUS: {result.get('WEB_SCRAPER_STATUS', 'NOT SET')}")
            print(f"   📋 Title: {result.get('title', 'NOT FOUND')}")
            print(f"   🏷️  Grant Number: {result.get('granT_NUMBER', 'NOT FOUND')}")
            print(f"   📅 Filing Date: {result.get('internationaL_FILING_DATE', 'NOT FOUND')}")
            print(f"   ⚖️  Status: {result.get('patenT_APPLICATION_STATUS', 'NOT FOUND')}")
            print(f"   🔗 PTO Site: {result.get('ptO_SITE', 'NOT FOUND')}")
            print(f"   🌐 Google Site: {result.get('googlE_SITE', 'NOT FOUND')}")

            has_meaningful_data = any([
                result.get('title'),
                result.get('granT_NUMBER'),
                result.get('patenT_APPLICATION_STATUS'),
                result.get('ptO_SITE'),
                result.get('googlE_SITE')
            ])
            
            if has_meaningful_data:
                print(f"✅ [{datetime.now().strftime('%H:%M:%S')}] SCRAPING SUCCESS: {app_no}")
                self.scraping_success_count += 1
            else:
                print(f"❌ [{datetime.now().strftime('%H:%M:%S')}] SCRAPING FAILED: {app_no}")
                self.scraping_error_count += 1

            # Save result to local file
            self.save_result_to_file(result)

            result_json = json.dumps(result, indent=2, default=str)
            if len(result_json) > 500:
                print(f"📄 Full result (truncated): {result_json[:500]}...")
            else:
                print(f"📄 Full result: {result_json}")
            
            return {
                "success": True,
                "app_no": app_no,
                "country": country,
                "scrape_result": result,
                "scraping_successful": has_meaningful_data,
                "input": message_data
            }

        except Exception as e:
            print(f"💥 [{datetime.now().strftime('%H:%M:%S')}] SCRAPING EXCEPTION: {app_no} - {str(e)}")
            logger.error(f"Scraping error: {e}")
            self.scraping_error_count += 1
            return {"success": False, "error": str(e), "input": message_data}

    async def handle_message(self, message):
        try:
            message_body = message.body.decode()
            message_data = json.loads(message_body)

            print(f"\n🔄 [{datetime.now().strftime('%H:%M:%S')}] PROCESSING MESSAGE: {message_data.get('app_no', 'N/A')} ({message_data.get('country', 'N/A')})")
            logger.info(f"Received: {message_data}")

            result = await self.process_scrape_request(message_data)
            self.processed_count += 1

            if result.get('success'):
                try:
                    app_no = result.get('app_no', 'N/A')
                    country = result.get('country', 'N/A')
                    scraping_successful = result.get('scraping_successful', False)

                    if scraping_successful:
                        print(f"📤 [{datetime.now().strftime('%H:%M:%S')}] SENDING GOOD DATA TO API: {app_no} ({country})")
                    else:
                        print(f"⚠️  [{datetime.now().strftime('%H:%M:%S')}] SENDING EMPTY DATA TO API: {app_no} ({country})")

                    api_response = await annuity_client.post_results([result.get('scrape_result', {})])

                    self.api_success_count += 1
                    print(f"✅ [{datetime.now().strftime('%H:%M:%S')}] ANNUITY API SUCCESS: {app_no} ({country})")
                    print(f"   📊 API Response: {api_response}")
                    logger.info(f"Result sent to Annuity API. Response: {api_response}")

                except Exception as e:
                    self.api_error_count += 1
                    print(f"❌ [{datetime.now().strftime('%H:%M:%S')}] ANNUITY API ERROR: {app_no} ({country})")
                    print(f"   🚨 Error: {str(e)}")
                    logger.error(f"Error posting to Annuity API: {e}")
            else:
                print(f"💥 [{datetime.now().strftime('%H:%M:%S')}] MESSAGE PROCESSING FAILED: {message_data.get('app_no', 'N/A')}")
                print(f"   Error: {result.get('error', 'Unknown error')}")

            await rabbitmq_manager.publish_message(settings.QUEUE_RESP, result)

            print(f"📈 [{datetime.now().strftime('%H:%M:%S')}] STATS: Total={self.processed_count}, Scrape✅={self.scraping_success_count}, Scrape❌={self.scraping_error_count}, API✅={self.api_success_count}, API❌={self.api_error_count}")

            await message.ack()
            logger.info("Message processed and acknowledged.")

        except Exception as e:
            print(f"💥 [{datetime.now().strftime('%H:%M:%S')}] MESSAGE HANDLING ERROR: {str(e)}")
            logger.error(f"Error handling message: {e}")
            await message.nack(requeue=True)

# Global instance
message_processor = MessageProcessor()
