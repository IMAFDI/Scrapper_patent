import os
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

import aiohttp
from aiohttp.client_exceptions import ClientError

logger = logging.getLogger(__name__)


class AnnuityApiClient:
    """
    Async API client modelled on the stable logic from ReqTemplateData_Service.py.
    Keeps one long-lived session, auto-refreshes token, centralises retry / back-off.
    """

    def __init__(self) -> None:
        # configuration from ENV (matching the working service)
        self.base_url: str = os.getenv("API_BASE_URL", "https://annuitybe.mintwaystech.in/api").rstrip("/")
        self.login_url: str = os.getenv("LOGIN_URL", f"{self.base_url}/Login")
        self.get_url: str = os.getenv("GET_API", f"{self.base_url}/TemplateRequestUpload/GetUploadedApplicationDetails")
        self.upload_url: str = os.getenv("ADMIN_DETAILS_BULK_UPLOAD_URL", f"{self.base_url}/TemplateRequestUpload/UpdateAdminRenewalDetailsFromBulkUpload")
        
        self.email: str = os.getenv("LOGIN_EMAIL", "system")
        self.password: str = os.getenv("LOGIN_PASSWORD", "P@ssw0rd4321")

        # runtime state
        self._token: Optional[str] = None
        self._token_expiry: datetime = datetime.min
        self._session: Optional[aiohttp.ClientSession] = None

        # retry policy
        self._max_retries: int = int(os.getenv("API_MAX_RETRIES", "4"))  # matching the working service
        self._retry_delay: float = float(os.getenv("API_RETRY_DELAY", "5"))  # matching the working service

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=30)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session

    async def _login(self) -> None:
        """Obtain / refresh bearer token using EXACT format from working service."""
        if datetime.utcnow() < self._token_expiry:
            return  # still valid

        headers = {
            "Content-Type": "application/json"
        }

        body_data = {
            "model": {
                "email": self.email,
                "password": self.password
            }
        }

        session = await self._ensure_session()
        
        # Retry logic matching the working service (up to 4 attempts)
        for attempt in range(1, self._max_retries + 1):
            try:
                async with session.post(self.login_url, headers=headers, json=body_data) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        print(f"Login api call successful: {data}")
                        
                        # Extract token from nested structure
                        if data and "model" in data and "token" in data["model"]:
                            self._token = data["model"]["token"]
                            self._token_expiry = datetime.utcnow() + timedelta(minutes=55)
                            logger.info("Annuity API authenticated; token valid until %s", self._token_expiry)
                            return
                        else:
                            raise RuntimeError(f"Token not found in response: {data}")
                    else:
                        print(f"Login failed with status code: {resp.status}")
                        if attempt < self._max_retries:
                            await asyncio.sleep(self._retry_delay)
                        else:
                            raise RuntimeError(f"Login failed [{resp.status}] after {self._max_retries} attempts")
                            
            except (ClientError, asyncio.TimeoutError) as exc:
                print(f"Login attempt {attempt} failed: {exc}")
                if attempt < self._max_retries:
                    await asyncio.sleep(self._retry_delay)
                else:
                    raise

    async def _request(self, method: str, url: str, *, json: Any | None = None) -> Any:
        """Centralised wrapper with token handling and retries."""
        await self._login()

        session = await self._ensure_session()
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._token}"
        }

        for attempt in range(1, self._max_retries + 1):
            try:
                async with session.request(method, url, json=json, headers=headers) as resp:
                    if resp.status == 401 and attempt == 1:
                        # token may have expired early – refresh once
                        self._token_expiry = datetime.min
                        await self._login()
                        headers["Authorization"] = f"Bearer {self._token}"
                        continue

                    if 200 <= resp.status < 300:
                        return await resp.json()

                    print(f"API call failed with status code: {resp.status}")
                    raise RuntimeError(f"{method} {url} failed [{resp.status}]")
                    
            except (ClientError, asyncio.TimeoutError) as exc:
                if attempt == self._max_retries:
                    raise
                logger.warning("API call %s %s failed (%s) – retrying %s/%s", method, url, exc, attempt, self._max_retries)
                await asyncio.sleep(self._retry_delay)

    # ── public façade (mirrors normal service) ──
    async def get_payload(self) -> List[Dict[str, Any]]:
        """Fetch applications that need processing - EXACT format from working service."""
        data = await self._request("GET", self.get_url)
        print(f"API call successful: {data}")
        
        # Extract from nested model structure
        if data and "model" in data:
            return data["model"]
        return data or []

    async def post_results(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Send processed results back to Annuity BE - EXACT format from working service."""
        # Wrap in model structure like the working service
        scraped_body_data = {
            "model": results
        }
        
        # Use PUT method like the working service
        return await self._request("PUT", self.upload_url, json=scraped_body_data)

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()


# Instantiate a singleton so other modules can `from annuity_api import annuity_client`
annuity_client = AnnuityApiClient()
