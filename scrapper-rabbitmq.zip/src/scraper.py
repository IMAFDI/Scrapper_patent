import json
import asyncio
from driver_pool import initialize_driver 
from datetime import datetime, timezone
from regions import *

def generate_google_patent_url(app_number: str) -> str:
    from urllib.parse import quote
    return f"https://patents.google.com/?oq={quote(app_number)}"

when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')

def scrape_by_region(driver, region, app_no, template_id):
    print(f"➡️ Entered scrape_by_region: region={region}, app_no={app_no}")
    try:
        match region:
            case "NZ":
                print("✅ Using scrape_NZ")
                return scrape_NZ(driver, app_no, template_id)
            case "CA":
                print("✅ Using scrape_CA")
                return scrape_CA(app_no, template_id)
            case "AU":
                print("✅ Using scrape_AU")
                return scrape_AU(driver, app_no, template_id)
            case "US":
                print("✅ Using scrape_US")
                return scrape_US(driver, app_no, generate_google_patent_url(app_no), template_id)
            case "EP": return scrape_EP(app_no, template_id)
            case "GB": return scrape_GB(driver, app_no, template_id)
            case "DE": return scrape_DE(driver, app_no, template_id)
            case "FR": return scrape_FR(driver, app_no, template_id)
            case "CN": return scrape_CN(driver, app_no, template_id)
            case "BR": return scrape_BR(driver, app_no, template_id)
            case "NL": return scrape_NL(driver, app_no, template_id)
            case "CH": return scrape_CH(driver, app_no, template_id)
            case "BE": return scrape_BE(driver, app_no, template_id)
            case "IE": return scrape_IE(driver, app_no, template_id)
            case "SE": return scrape_SE(driver, app_no, template_id)
            case "PL": return scrape_PL(driver, app_no, template_id)
            case "FI": return scrape_FI(driver, app_no, template_id)
            case "JP": return scrape_JP(driver, app_no, template_id)
            case "TR": return scrape_TR(app_no, template_id)
            case "AT": return scrape_AT(app_no, template_id)
            case "DK": return scrape_DK(app_no, template_id)
            case "GR": return scrape_GR(app_no, template_id)
            case "ES": return scrape_ES(driver, app_no, template_id)
            case "PT": return scrape_PT(app_no, template_id)
            case "HU": return scrape_HU(app_no, template_id)
            case _:
                print(f"❌ Region {region} not supported!")
                return {
                    "templatE_REQUEST_UPLOAD_ID": template_id,
                    "wheN_RUN": when_run,
                    "applicatioN_NUMBER": f"EP{app_no}",
                    "countrY_ISO2_CODE": region,
                    "WEB_SCRAPER_STATUS": False,
                    "error": f"Unsupported region: {region}"
                }
    except Exception as e:
        print(f"❌ Error in scrape_by_region for {region} - {app_no}: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": f"EP{app_no}",
            "countrY_ISO2_CODE": region,
            "WEB_SCRAPER_STATUS": False,
            "error": str(e)
        }

def scrape_many(data: list):
    results = []
    driver = initialize_driver()  
    try:
        for item in data:
            template_id = item.get("templatE_REQUEST_UPLOAD_ID", "")
            app_no = item.get("applicatioN_NUMBER", "")
            region = item.get("countrY_ISO2_CODE", "")

            print(f"\n📥 Received from Annuity API:\n  App No: {app_no}\n  Country: {region}\n  Template ID: {template_id}")

            if not region or not app_no:
                print("⚠️ Missing region or application number")
                results.append({
                    "templatE_REQUEST_UPLOAD_ID": template_id,
                    "wheN_RUN": when_run,
                    "applicatioN_NUMBER": app_no,
                    "countrY_ISO2_CODE": region,
                    "WEB_SCRAPER_STATUS": False,
                    "error": "Missing region or application number"
                })
                continue

            print(f"📩 Starting scrape for: {app_no} ({region}) with template_id={template_id}")
            try:
                result = scrape_by_region(driver, region, app_no, template_id)
                print(f"🟢 SUCCESS: {app_no} ({region}) ➤ Keys: {list(result.keys())}, Status: {result.get('WEB_SCRAPER_STATUS')}")
                results.append(result)
            except Exception as e:
                print(f"❌ Scraping failed for {app_no} ({region}): {e}")
                results.append({
                    "templatE_REQUEST_UPLOAD_ID": template_id,
                    "wheN_RUN": when_run,
                    "applicatioN_NUMBER": app_no,
                    "countrY_ISO2_CODE": region,
                    "WEB_SCRAPER_STATUS": False,
                    "error": str(e)
                })
    finally:
        driver.quit()
    return results

async def scrape_data(payload: list):
    print(f"\n📦 scrape_data received payload: {json.dumps(payload, indent=2)}")
    for item in payload:
        print(f"🔎 Will process: App No={item.get('applicatioN_NUMBER')} | Country={item.get('countrY_ISO2_CODE')} | Template ID={item.get('templatE_REQUEST_UPLOAD_ID')}")
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, scrape_many, payload)
