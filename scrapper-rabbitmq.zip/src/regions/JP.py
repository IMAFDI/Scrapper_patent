from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from dateutil.relativedelta import relativedelta
from datetime import datetime
from datetime import datetime, timezone
import re
import time


# Japan Region
def scrape_JP(driver, application_number, template_id):

    def extract_value_by_label(label_text, which='first'):
        try:
            xpath = f"//tr[th[contains(text(), '{label_text}')]]/td//span"
            elements = driver.find_elements(By.XPATH, xpath)
            elements = [el for el in elements if el.text.strip()]

            if not elements:
                return ""

            if which == 'first':
                return elements[0].text.strip()
            elif which == 'last':
                return elements[-1].text.strip()
            elif which == 'all':
                return ' '.join(el.text.strip() for el in elements)
            else:
                return ""
        except Exception as e:
            print(f"Error extracting label '{label_text}': {e}")
            return ""

    url = "https://www.j-platpat.inpit.go.jp/s0000/en"
    driver.get(url)

    try:
        input_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "s01_srchCondtn_txtSimpleSearch"))
        )
        input_element.clear()
        input_element.send_keys(application_number + Keys.ENTER)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        print(f"Searching for: {application_number}")
        print("-" * 20)

        # Click Search Button
        search_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, "s01_srchBtn_btnSearch"))
        )
        search_button.click()
        print("✅ Clicked Search button.")
        time.sleep(3)

        # Click View Details button
        view_details_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, "patentUtltyIntnlNumOnlyLst_tableView_progReferenceInfo0"))
        )
        view_details_button.click()
        print("✅ Clicked View Details button.")

        # Switch to new tab
        original_window = driver.current_window_handle
        timeout = 20
        start_time = time.time()

        while len(driver.window_handles) == 1:
            if time.time() - start_time > timeout:
                raise Exception("Timeout: New tab did not open.")
            time.sleep(0.5)

        print("✅ New tab detected.")
        new_window = [window for window in driver.window_handles if window != original_window][0]
        driver.switch_to.window(new_window)
        print(f"✅ Switched to new tab: {new_window}")

        # Click Registration Information tab
        registration_tab = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, "mat-tab-group-0-label-2"))
        )
        print("✅ Registration Information tab is visible.")
        registration_tab.click()
        print("✅ Clicked 'Registration Information' tab.")
        time.sleep(5)

        # Grant Number
        grant_number_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, 'panel-subTitle'))
        )
        grant_number_raw = grant_number_element.text.strip()
        grant_number = f"EP{grant_number_raw}"

        # Title
        title = extract_value_by_label("Articles on name (in Chinese characters) of invention", which='first')

        # Filed By (Right Holder)
        filled_by_text = extract_value_by_label("Articles on right holder", which='last')

        def clean_and_format_date(raw_date_str):
            raw_date_str = raw_date_str.replace("(", "").replace(")", "").replace(".", "")
            raw_date_str = raw_date_str.strip()

            possible_formats = [
                "%b %d,%Y",
                "%b%d,%Y"
            ]

            for fmt in possible_formats:
                try:
                    parsed_date = datetime.strptime(raw_date_str, fmt)
                    return parsed_date.strftime("%Y-%m-%d")
                except:
                    continue

            # If no format matched:
            print(f"Error parsing date '{raw_date_str}': no matching format.")
            return ""



        # International Filing Date → Articles on application
        application_text = extract_value_by_label("Articles on application", which='all')
        application_date_match = re.search(r"\((.*?)\)", application_text)
        if application_date_match:
            date_cleaned = clean_and_format_date(application_date_match.group(1))
            filing_date = date_cleaned + "T00:00:00.000Z"
        else:
            filing_date = None

        # Grant Date → Articles on registration
        registration_text = extract_value_by_label("Articles on registration", which='all')
        registration_date_match = re.search(r"\((.*?)\)", registration_text)
        if registration_date_match:
            date_cleaned = clean_and_format_date(registration_date_match.group(1))
            grant_date = date_cleaned + "T00:00:00.000Z"
        else:
            grant_date = None


        # Due Date
        final_payment_year_text = extract_value_by_label("Articles on final payment year", which='first')
        try:
            num_years = int(''.join(filter(str.isdigit, final_payment_year_text)))
            grant_date_dt = datetime.strptime(grant_date[:10], "%Y-%m-%d")  # Strip time if present
            due_date_dt = grant_date_dt + relativedelta(years=num_years)
            due_date = due_date_dt.strftime("%Y-%m-%d") + "T00:00:00.000Z"
            print(due_date)
        except:
            due_date = None


        # Status
        status = extract_value_by_label("Articles on detailed registration items", which='first')

        # Claims
        claims_text = extract_value_by_label("Articles on the number of claims", which='first')
        claims_count = ''.join(filter(str.isdigit, claims_text))

        # Other static fields
        entity = "Large"
        lawyer = ""
        DE_number = ""
        application_type = ""
        google_site = ""
        PTO_site = driver.current_url

        # Close current tab (Registration tab)
        driver.close()
        print("✅ Closed Registration tab.")

        # Wait for the window handles to reduce
        timeout = 5
        start_time = time.time()

        while len(driver.window_handles) < 1:
            if time.time() - start_time > timeout:
                print("⚠️ Timeout waiting for window to close.")
                break
            time.sleep(0.5)

        # Switch back to original window
        driver.switch_to.window(original_window)
        print("✅ Switched back to search page.")

        # Return result
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "JP",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "CLAIMS_COUNT": claims_count,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }

    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "JP",
            "WEB_SCRAPER_STATUS": False
        }