# from selenium.webdriver.common.by import By
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from selenium.common.exceptions import NoSuchElementException
# # from seleniumbase import Driver
# from datetime import datetime
# from datetime import datetime, timezone
# import calendar
# import re

# #funtion Defination for Europe scraping
# def scrape_EP(driver,application_number, template_id):

#     # driver = Driver(uc =True)
#     url = f"https://register.epo.org/application?number=EP{application_number.split('.')[0]}"
#     print(url)
#     driver.get(url)
#     # driver.uc_open_with_reconnect(url, 4)

    
#     try:
#         print(f"Searching for: {application_number}")
#         print("-" * 20)
        
#         when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
#         application_number = application_number


#         #extract grant number
#         try:
#             grant_number_element = WebDriverWait(driver, 10).until (
#             EC.visibility_of_element_located((By.XPATH, '//*[@id="pagebody"]/h1'))
#             )
#             grant_number_full = grant_number_element.text.strip()
                  
#             match = re.search(r'EP\d+', grant_number_full)
#             if match:
#                 grant_number = match.group()

#         except NoSuchElementException:
#             grant_number = ""
 

#         #title extraction
#         try:
#             title_element = driver.find_element(By.XPATH, "//*[@id='body']/table/tbody/tr[1]/td/b/font/a")
#             full_title = title_element.text.strip()
#             title = full_title.split(" - ", 1)[1]

#         except NoSuchElementException:
#             title = ""

#         #entity extraction
#         entity = "Large"
#         #
#         #
#         #


#         #filled by
#         try:
#             rows = driver.find_elements(By.XPATH, '//table[@class="tableType3 printTable"]/tbody/tr')
#             # Loop through each row
#             for row in rows:
#                 # Try to find the target cell
#                 try:
#                     applicant_target_cell = row.find_element(By.XPATH, './td[@class="th" and contains(text(), "Applicant(s)")]')
#                     # If found, get the date cell
#                     if applicant_target_cell:
#                         appliacant_cell = row.find_element(By.XPATH, './td[@class="t2"]')
#                         break
#                 except:
#                     continue

#             filled_by = appliacant_cell.get_attribute('innerHTML')

#             # Split by <br> and clean up
#             lines = [line.strip() for line in filled_by.split('<br>') if line.strip()]

#             # Get line after "For all designated states"
#             for i, line in enumerate(lines):
#                 if "For all designated states" in line and i + 1 < len(lines):
#                     filled_by_text = lines[i + 1]
#                     break
#             else:
#                 filled_by_text = ""

#         except NoSuchElementException:
#             filled_by_text = ""
        

#         #international filing date
#         filing_date = None
#         try:
#             # Get all rows in the table
#             rows = driver.find_elements(By.XPATH, '//table[@class="tableType3 printTable"]/tbody/tr')

#             # Loop through each row
#             for row in rows:
#                 # Try to find the target cell
#                 try:
#                     target_cell = row.find_element(By.XPATH, './td[@class="th" and contains(text(), "Application number, filing date")]')
#                     # If found, get the date cell
#                     if target_cell:
#                         date_cell = row.find_element(By.XPATH, './td[@class="t3"]').text.strip()
#                         filing_date = f"{datetime.strptime(date_cell, '%d.%m.%Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
#                         break
#                 except:
#                     continue
#         except NoSuchElementException:
#             filing_date = None
        

#         #grant date extraction
#         grant_date = None
#         try:
#             # Get all rows in the table
#             rows = driver.find_elements(By.XPATH, '//table[@class="tableType3 printTable"]/tbody/tr')

#             # Loop through each row
#             for row in rows:
#                 # Try to find the target cell
#                 try:
#                     target_cell = row.find_element(By.XPATH, './td[@class="t3" and contains(text(), "Fee for grant paid")]')
#                     # If found, get the date cell
#                     if target_cell:
#                         date_cell = row.find_element(By.XPATH, './td[@class="t2"]').text.strip()
#                         grant_date = f"{datetime.strptime(date_cell, '%d.%m.%Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
#                         break
#                 except:
#                     continue
#         except NoSuchElementException:
#             grant_date = None


#         #due date extraction
#         due_date = None
#         try:
#             # Get all rows in the table
#             rows = driver.find_elements(By.XPATH, '//table[@class="tableType3 printTable"]/tbody/tr')
#             # Loop through each row
#             for row in reversed(rows):
#                 # Try to find the target cell
#                 try:
#                     target_cell = row.find_element(By.XPATH, './td[@class="t3" and contains(text(), "Renewal fee")]')
#                     # If found, get the date cell
#                     if target_cell:
#                         target_text = target_cell.text.strip()
#                         match = re.search(r'\d+', target_text)
#                         if match:
#                             number = match.group()
#                             # Convert to datetime object
#                             date_obj = datetime.strptime(filing_date.replace("T00:00:00.000Z", ""), "%Y-%m-%d")

#                             # Calculate new year and month
#                             new_year = date_obj.year + int(number)
#                             new_month = date_obj.month

#                             # Get last day of the new month
#                             last_day = calendar.monthrange(new_year, new_month)[1]

#                             # Build new due date
#                             due_date = datetime(new_year, new_month, last_day).strftime("%Y-%m-%dT00:00:00.000Z")
#                             break
#                 except:
#                     continue
#         except NoSuchElementException:
#             print(str(e))
#             # due_date = None
        
#         #lawyer extraction
#         try:
#             rows = driver.find_elements(By.XPATH, '//table[@class="tableType3 printTable"]/tbody/tr')
#             # Loop through each row
#             for row in rows:
#                 # Try to find the target cell
#                 try:
#                     lawyer_target_cell = row.find_element(By.XPATH, './td[@class="th" and contains(text(), "Representative(s)")]')
#                     # If found, get the date cell
#                     if lawyer_target_cell:
#                         lawyer_cell = row.find_element(By.XPATH, './td[@class="t2"]')
#                         break
#                 except:
#                     continue

#             lawyer_text = lawyer_cell.get_attribute('innerHTML')

#             # Split by <br> and clean up
#             lines = [line.strip() for line in lawyer_text.split('<br>') if line.strip()]

#             # Get the first line as the lawyer name
#             if lines:
#                 lawyer = lines[0]
#             else:
#                 lawyer = ""

#         except NoSuchElementException:
#             lawyer = ""
        
#         DE_number = ""

#         #status extraction
#         try:
#             rows = driver.find_elements(By.XPATH, '//table[@class="tableType3 printTable"]/tbody/tr')
#             # Loop through each row
#             for row in rows:
#                 # Try to find the target cell
#                 try:
#                     status_target_cell = row.find_element(By.XPATH, './td[@class="th" and contains(text(), "Status")]')
#                     # If found, get the date cell
#                     if status_target_cell:
#                         status_cell = row.find_element(By.XPATH, './td[@class="t2"]')
#                         break
#                 except:
#                     continue

#             status_text = status_cell.get_attribute('innerHTML')

#             # Split by <br> and clean up
#             lines = [line.strip() for line in status_text.split('<br>') if line.strip()]

#             # Get the first line as the status
#             if lines:
#                 status = lines[0]
#             else:
#                 status = ""

#         except NoSuchElementException:
#             status = ""
        
#         application_type = ""
#         google_site = ""
#         PTO_site = driver.current_url

#         # try:
#         #     driver.quit()
#         # except:
#         #     pass

#         # Check if due_date or filing_date or entity is missing
#         if filing_date is None or due_date is None or entity == "":
#             return {
#                 "templatE_REQUEST_UPLOAD_ID": template_id,
#                 "applicatioN_NUMBER": application_number,
#                 "countrY_ISO2_CODE": "EP",
#                 "WEB_SCRAPER_STATUS": False
#             }       


#         return {
#             "templatE_REQUEST_UPLOAD_ID": template_id,
#             "wheN_RUN": when_run,
#             "applicatioN_NUMBER": application_number,
#             "countrY_ISO2_CODE": "EP",
#             "granT_NUMBER": grant_number,
#             "title": title,
#             "entitY_SIZE": entity,
#             "fileD_BY": filled_by_text,
#             "internationaL_FILING_DATE": filing_date,
#             "granT_DATE": grant_date,
#             "duE_DATE" : due_date,
#             "lawyer": lawyer,
#             "dE_NUMBER": DE_number,
#             "patenT_APPLICATION_STATUS": status,
#             "applicatioN_TYPE_NAME": application_type,
#             "googlE_SITE": google_site,
#             "ptO_SITE": PTO_site,
#             "WEB_SCRAPER_STATUS": True
#         }


#     except Exception as e:

#         # try:
#         #     driver.quit()
#         # except:
#         #     pass
        
#         print(f"Error occurred: {e}")
#         return {
#             "templatE_REQUEST_UPLOAD_ID": template_id,
#             "wheN_RUN": when_run,
#             "applicatioN_NUMBER": application_number,
#             "countrY_ISO2_CODE": "EP",
#             "WEB_SCRAPER_STATUS": False
#         }

from selenium.webdriver.common.by import By 
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime, timezone
import calendar
import re
import requests
from lxml import etree

import base64
import requests

def get_epo_access_token(consumer_key, consumer_secret):
    token_url = "https://ops.epo.org/3.2/auth/accesstoken"
    credentials = f"{consumer_key}:{consumer_secret}"
    b64_credentials = base64.b64encode(credentials.encode()).decode()

    headers = {
        "Authorization": f"Basic {b64_credentials}",
        "Content-Type": "application/x-www-form-urlencoded"
    }

    data = {"grant_type": "client_credentials"}

    response = requests.post(token_url, headers=headers, data=data)

    if response.status_code == 200:
        return response.json()["access_token"]
    else:
        print("Failed to get access token:", response.text)
        return None

# Function Defination for Europe scraping
def scrape_EP(application_number, template_id):
    url = f"https://register.epo.org/application?number=EP{application_number.split('.')[0]}"


    try:
        print(f"Searching for: {application_number}")
        print("-" * 20)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')

        # --- API FETCH ---
        grant_number = title = filled_by_text = filing_date = lawyer = ''
        api_url = f"https://ops.epo.org/3.2/rest-services/register/application/epodoc/EP{application_number.split('.')[0]}/biblio"
        headers = {
            "Accept": "application/xml",
            "Authorization": f"Bearer {get_epo_access_token('RlHrjzojCNOpqpsaaroCfSILIGqrUFeXDR4SENKud7O9p9ln', 'zvZuaTj819r23as7sOYJYY9GpX4K8Xm4oOA3S8okgcXJrarKoigaFGps0TUBgbJX')}"
        }
        try:
            api_resp = requests.get(api_url, headers=headers)
            if api_resp.status_code == 200:
                xml = etree.fromstring(api_resp.content)
                ns = {
                    'ops': 'http://ops.epo.org',
                    'reg': 'http://www.epo.org/register'
                }

                # granT_NUMBER from EP publication-reference
                doc_nodes = xml.xpath('//reg:publication-reference/reg:document-id[reg:country="EP"]/reg:doc-number', namespaces=ns)
                if doc_nodes:
                    grant_number = doc_nodes[0].text.strip()

                # title in English
                title_nodes = xml.xpath('//reg:invention-title[@lang="en"]', namespaces=ns)
                if title_nodes:
                    title = title_nodes[0].text.strip()

                # filed_by_text (first applicant name)
                filed_by_nodes = xml.xpath('//reg:parties/reg:applicants/reg:applicant/reg:addressbook/reg:name', namespaces=ns)
                if filed_by_nodes:
                    filled_by_text = filed_by_nodes[0].text.strip()

                # international_filing_date (EP doc)
                date_nodes = xml.xpath('//reg:application-reference/reg:document-id[reg:country="EP"]/reg:date', namespaces=ns)
                if date_nodes:
                    filing_date = datetime.strptime(date_nodes[0].text.strip(), "%Y%m%d").strftime("%Y-%m-%dT00:00:00.000Z")

                # lawyer / agent name (latest change-date agent)
                agent_nodes = xml.xpath('//reg:parties/reg:agents/reg:agent/reg:addressbook/reg:name', namespaces=ns)
                if agent_nodes:
                    lawyer = agent_nodes[0].text.strip()

        except Exception as e:
            print(f"Failed fetching from OPS API BIBLIO: {e}")



        # --- API FETCH (Events) ---
        due_date = None
        status = ""
        try:
            events_url = f"https://ops.epo.org/3.2/rest-services/register/application/epodoc/EP{application_number}/events"
            headers = {
                "Accept": "application/xml",
                "Authorization": f"Bearer {get_epo_access_token('RlHrjzojCNOpqpsaaroCfSILIGqrUFeXDR4SENKud7O9p9ln', 'zvZuaTj819r23as7sOYJYY9GpX4K8Xm4oOA3S8okgcXJrarKoigaFGps0TUBgbJX')}"
            }
            resp = requests.get(events_url, headers=headers)
            if resp.status_code == 200:
                xml = etree.fromstring(resp.content)
                ns = {
                    'ops': 'http://ops.epo.org',
                    'reg': 'http://www.epo.org/register'
                }

                # Get latest patent status
                statuses = xml.xpath('//reg:ep-patent-status', namespaces=ns)
                if statuses:
                    latest_status = sorted(
                        statuses,
                        key=lambda x: x.attrib.get("change-date", "")
                    )[-1]
                    status = latest_status.text.strip()

                # Get all renewal fee dates
                renewal_nodes = xml.xpath('//reg:dossier-event[reg:event-text="New entry: Renewal fee paid"]/reg:event-date/reg:date', namespaces=ns)
                renewal_dates = [node.text for node in renewal_nodes if node is not None]

                if renewal_dates:
                    latest_due = max(renewal_dates)
                    due_date_obj = datetime.strptime(latest_due, "%Y%m%d")
                    if filing_date:
                        filing_dt = datetime.strptime(filing_date.replace("T00:00:00.000Z", ""), "%Y-%m-%d")
                        annuity_year = due_date_obj.year - filing_dt.year
                        new_year = filing_dt.year + annuity_year
                        new_month = filing_dt.month
                        last_day = calendar.monthrange(new_year, new_month)[1]
                        due_date = datetime(new_year, new_month, last_day).strftime("%Y-%m-%dT00:00:00.000Z")
        except Exception as e:
            print(f"Failed fetching from OPS API (events): {e}")



        entity = "Large"
        grant_date = None
        # due_date = None
        # lawyer = ""
        DE_number = ""
        # status = ""
        application_type = ""
        google_site = ""
        PTO_site = url

        # Return with parsed API data
        # if filing_date is None or entity == "":
        #     return {
        #         "templatE_REQUEST_UPLOAD_ID": template_id,
        #         "applicatioN_NUMBER": application_number,
        #         "countrY_ISO2_CODE": "EP",
        #         "WEB_SCRAPER_STATUS": False
        #     }

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "EP",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }

    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "EP",
            "WEB_SCRAPER_STATUS": False
        }
