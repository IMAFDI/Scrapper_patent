from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from seleniumbase import Driver
from datetime import datetime
from datetime import datetime, timezone
import time
from bs4 import BeautifulSoup


# Cheg Republic Region
def scrape_CZ(application_number, template_id):

    # Normalize application number to EP######## format
    application_number_clean = application_number.upper().replace("EP", "").replace("E", "").split('.')[0]
    app_no = "EP" + application_number_clean


    driver = Driver(uc =True)
    url = f"https://register.epo.org/application?number={app_no}"
    print(url)
    driver.uc_open_with_reconnect(url, 4)

    # region specific logic for CZ
    try: 
        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        print(f"Searching for: {app_no}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        # Click on Legal Status
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "epoContentNav"))
        )

        # Find and click the "EP Legal status" link
        legal_status_link = driver.find_element(By.XPATH, "//a[contains(text(),'EP Legal status')]")
        print("🔗 Clicking on: EP Legal status")
        legal_status_link.click()

        # Wait 5 seconds on the new page
        print("⏳ Waiting 5 seconds on Legal status page...")
        time.sleep(5)

        # Now click on CZ Link
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "ext"))
        )

        # Find the <a> tag with text "CZ" and click it
        tr_link = driver.find_element(By.XPATH, "//a[@class='ext' and text()='CZ']")
        tr_url = tr_link.get_attribute("href")
        print(f"🔗 Found IS link: {tr_url}")

        # Navigate to the Cheg Republic patent register link
        driver.get(tr_url)

        # Wait on that page for 5 seconds
        print("⏳ Waiting 5 seconds on Iceland site...")
        time.sleep(5)

        

        def format_date(date_str):
            """Convert 'dd.mm.yyyy' to 'yyyy-mm-ddT00:00:00.000Z'"""
            try:
                return datetime.strptime(date_str.strip(), "%d.%m.%Y").strftime("%Y-%m-%dT00:00:00.000Z")
            except:
                return ""

        # Load your HTML here
        soup = BeautifulSoup(driver.page_source, "html.parser")  # use your HTML string or driver.page_source

        # Helper function to extract value by label text
        def extract_value_by_label(label_text):
            label = soup.find('div', class_='headmd', string=lambda t: t and label_text in t)
            if label:
                value = label.find_next_sibling('div')
                return value.get_text(strip=True)
            return ""

        # Scrape values

        # Application Number
        application_number = extract_value_by_label('EP application number')

        # Grant Number
        raw_grant_number = extract_value_by_label('(11)') # Number of published EP application
        grant_number = f"EP{raw_grant_number.strip()}"  

        # Title
        title_block = extract_value_by_label('(54)')
        title = title_block.split('EN:')[-1].split('CS:')[0].strip() if 'EN:' in title_block else title_block

        # Filed By
        try:
            filled_by_text = extract_value_by_label('(71/73)')
            filing_date = format_date(extract_value_by_label('(22)'))
        except NoSuchElementException:
            filing_date = None    

        # Grant Date
        grant_date = format_date(extract_value_by_label('(47)'))

        # Lawyer
        lawyer = extract_value_by_label('Representative')
        
        # Due Date
        # Find all tlpoint divs
        timeline_points = soup.select('div.timelinediv div.tlpoint')

        due_date = None

        for point in timeline_points:
            label = point.find('p')
            if label and "maintenance fees" in label.text.lower():
                date_span = point.find('span', class_='dtm')
                if date_span:
                    due_date = format_date(date_span.text)
                break

        print("due_date:", due_date)
        
        # Status
        status = extract_value_by_label('Status')

        entity = ""
        DE_number = ""
        application_type = ""
        google_site = ""
        

        # Extracting the current URL
        PTO_site = driver.current_url

        # ✅ Close the driver once scraping is done
        driver.quit()

        # Check if due_date or filing_date or entity is missing
        if filing_date is None or due_date is None:
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "wheN_RUN": when_run,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "CZ",
                "WEB_SCRAPER_STATUS": False
            }  

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "CZ",
            "granT_NUMBER": grant_number,
            "title" : title,
            "entity_size": entity,
            "fileD_BY": filled_by_text,
            "international_filing_date": filing_date,
            "grant_date": grant_date,
            "due_date": due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        try:
            driver.quit()  # Make sure driver still closes on error
        except:
            pass
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "CZ",
            "WEB_SCRAPER_STATUS": False
        }