from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from dateutil.relativedelta import relativedelta
from seleniumbase import Driver
from fake_useragent import UserAgent
from datetime import datetime, timedelta, timezone
import calendar
import re
import time
import json
import requests
from bs4 import BeautifulSoup
import urllib


def scrape_KR(driver, application_number, template_id):
    url = "https://www.kipris.or.kr/khome/search/searchResult.do?tab=patent"
    driver.get(url)

    try:
        input_element = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//*[@id="queryText"]'))
        )
        input_element.clear()
        input_element.send_keys(application_number + Keys.ENTER)
        time.sleep(5)

        button = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//button[contains(@onclick, 'openDetail')]"))
        )
        actions = ActionChains(driver)
        actions.move_to_element(button).click().perform()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="mainResultDetail"]/div[2]/div[1]/div[1]/div[1]/div[2]/table'))
        )

        print(f"Searching for: {application_number}")
        print("-" * 20)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        print("When Run: ", when_run)

        # Initialize all fields
        grant_number = ""
        title = ""
        filled_by_text = ""
        filing_date = None
        grant_date = None
        due_date = None
        status = ""
        PTO_site = ""
        entity = ""
        DE_number = ""
        lawyer = ""
        application_type = ""
        google_site = ""

        try:
            table = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="mainResultDetail"]/div[2]/div[1]/div[1]/div[1]/div[2]/table'))
            )
            rows = table.find_elements(By.XPATH, ".//tbody/tr")
            for row in rows:
                try:
                    left = row.find_element(By.XPATH, ".//th[@scope='row']").text.strip()
                    right = row.find_element(By.XPATH, ".//td").text.strip()

                    if "Application No" in left and application_number == "":
                        application_number = right.replace(" ", "")
                    elif "Registration No" in left and grant_number == "":
                        grant_number = right.replace(" ", "")
                    elif "Applicant" in left and filled_by_text == "":
                        filled_by_text = right.strip()
                    elif "Application Date" in left and filing_date is None:
                        filing_date = f"{datetime.strptime(right.strip(), '%Y.%m.%d').strftime('%Y-%m-%d')}T00:00:00.000Z"
                    elif "Registration Date" in left and grant_date is None:
                        grant_date = f"{datetime.strptime(right.strip(), '%Y.%m.%d').strftime('%Y-%m-%d')}T00:00:00.000Z"
                    elif "Title" in left and title == "":
                        title = right.strip()
                    elif "Status" in left and status == "":
                        status = right.strip()

                except:
                    continue

        except NoSuchElementException:
            print("Table not found")

        print("application no: ", application_number)

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "KR",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE": due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }

    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "KR",
            "WEB_SCRAPER_STATUS": False
        }
