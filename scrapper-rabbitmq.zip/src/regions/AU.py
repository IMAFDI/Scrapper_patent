from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime
from datetime import datetime, timezone

# #Function Defination for Australia scraping
def scrape_AU(driver, application_number, template_id):

    url = f"https://ipsearch.ipaustralia.gov.au/patents/{application_number}"
    driver.get(url)
    try:
        print(f"Searching for: {application_number}")
        print("-" * 20)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        application_number = application_number
        grant_number = ""

        #title extraction
        try:
            title_element = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, '//*[@id="biblio-tabpanel"]/div/div/table/tbody[1]/tr[9]/td')))
            title = title_element.text.strip()

        except NoSuchElementException:
            title = ""
        

        entity = ""

        # filled by
        try:    
            filled_by_element = driver.find_element(By.XPATH, '//*[@id="biblio-tabpanel"]/div/div/table/tbody[2]/tr[2]/td')
            filled_by_text = filled_by_element.text.strip()

        except NoSuchElementException:
            filled_by_text = ""


        # international filing date
        try:
            filing_date_element = driver.find_element(By.XPATH, '//*[@id="biblio-tabpanel"]/div/div/table/tbody[1]/tr[14]/td')
            filing_date_raw = filing_date_element.text.strip().replace("July", "Jul").replace("June", "Jun")

            # Parse the date from '10-Jul-2021'
            filing_date = f"{datetime.strptime(filing_date_raw, '%d-%b-%Y').strftime('%Y-%m-%d')}T00:00:00.000Z"

            # # Add current UTC time
            # now = datetime.now(timezone.utc)
            # date_obj = date_obj.replace(
            #     hour=now.hour, minute=now.minute, second=now.second,
            #     microsecond=now.microsecond, tzinfo=timezone.utc
            # )

            # # Format to ISO 8601 with milliseconds and 'Z'
            # filing_date = date_obj.isoformat(timespec='milliseconds').replace('+00:00', 'Z')

        except NoSuchElementException:
            filing_date = None

        grant_date = None


        #due date
        try:
            due_date_element = driver.find_element(By.XPATH, '//*[@id="publication-tabpanel"]/div/table/tbody[1]/tr[3]/td')
            due_date_raw = due_date_element.text.strip().replace("July", "Jul").replace("June", "Jun")

            # Parse the date
            due_date = f"{datetime.strptime(due_date_raw, '%d-%b-%Y').strftime('%Y-%m-%d')}T00:00:00.000Z"

            # # Add current UTC time
            # now = datetime.now(timezone.utc)
            # date_obj = date_obj.replace(
            #     hour=now.hour, minute=now.minute, second=now.second,
            #     microsecond=now.microsecond, tzinfo=timezone.utc
            # )

            # # Format to ISO 8601 with milliseconds and 'Z'
            # due_date = date_obj.isoformat(timespec='milliseconds').replace('+00:00', 'Z')

        except NoSuchElementException:
            due_date = None
        

        #lawyer extracttion
        try:
            lawyer_element = driver.find_element(By.XPATH, '//*[@id="biblio-tabpanel"]/div/div/table/tbody[1]/tr[11]/td')
            lawyer = lawyer_element.text.strip()
            
            # If the name is in the format (MACLEAN, DOUGLAS J.), transform it to (DOUGLAS J. MACLEAN)
            if ',' in lawyer:
                parts = lawyer.split(',')
                lawyer = f"{parts[1].strip()} {parts[0].strip()}"

                
        except NoSuchElementException:
            lawyer = ""
        
        DE_number = ""

        #status
        try:
            status_element = driver.find_element(By.XPATH, '//*[@id="biblio-tabpanel"]/div/div/table/tbody[1]/tr[5]/td')
            status = status_element.text.strip()
        except NoSuchElementException:
            status = ""
         
        # application_type extraction
        try:
            application_type_element = driver.find_element(By.XPATH, '//*[@id="biblio-tabpanel"]/div/div/table/tbody[1]/tr[3]/td')
            application_type = application_type_element.text.strip()
        except NoSuchElementException:
            application_type = ""

        google_site = ""


        # Extracting the current URL
        PTO_site = driver.current_url

        # Check if due_date or filing_date is missing
        if filing_date is None or due_date is None:
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "wheN_RUN": when_run,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "AU",
                "WEB_SCRAPER_STATUS": False
            }      

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "AU",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
             "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }

    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "AU",
            "WEB_SCRAPER_STATUS": False
        }