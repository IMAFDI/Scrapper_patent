from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from dateutil.relativedelta import relativedelta
from datetime import datetime
from datetime import datetime, timezone
import calendar
import time


# Finland Region
def scrape_FI(driver, application_number, template_id):

    # Ensure application number starts with "EP"
    if not application_number.upper().startswith("EP"):
        app_no = "EP" + application_number

    url = f"https://patenttitietopalvelu.prh.fi/en/patent/{app_no}"
    driver.get(url)

    # region specific logic for FI
    try: 

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        application_number = application_number
        print(f"Searching for: {app_no}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        # Grant Number (2nd dd under Application and registration number)
        try:
            grant_number = driver.find_element(By.XPATH, "//dt[text()='Application and registration number']/following-sibling::dd[2]").text.strip()
        except:
            grant_number = ""
        
        # Title
        try:
            title = driver.find_element(By.XPATH, "//dt[text()='Title']/following-sibling::dd[1]").text.strip()
        except:
            title = ""

        # Filed By (Applicant/Holder)
        try:
            filled_by_text = driver.find_element(By.XPATH, "//dt[text()='Applicant/Holder']/following-sibling::dd[1]").text.strip()
        except:
            filled_by_text = ""

        # International Filing Date
        try:
            filing_raw = driver.find_element(By.XPATH, "//dt[text()='Filing date']/following-sibling::dd[1]").text.strip()
            filing_clean = filing_raw.split("T")[0].strip()
            filing_dt = datetime.strptime(filing_clean, "%d.%m.%Y")
            filing_date = filing_dt.strftime("%Y-%m-%dT00:00:00.000Z")
            print(filing_date)
        except:
            filing_date = None

        # Grant Date (Registration date)
        try:
            grant_raw = driver.find_element(By.XPATH, "//dt[text()='Registration date']/following-sibling::dd[1]").text.strip()
            grant_clean = grant_raw.split("T")[0].strip()
            grant_dt = datetime.strptime(grant_clean, "%d.%m.%Y")
            grant_date = grant_dt.strftime("%Y-%m-%dT00:00:00.000Z")
            print(grant_date)
        except:
            grant_date = None


        # Due Date
        try:
            # Clean the international filing date
            filing_date_clean = filing_date.split("T")[0]
            filing_date_raw = datetime.strptime(filing_date_clean, "%Y-%m-%d")

            # Locate fee table rows
            rows = driver.find_elements(By.XPATH, "//table[@class='table']/tbody/tr")
            max_year = 0

            for row in rows:
                cols = row.find_elements(By.TAG_NAME, "td")
                if len(cols) < 2:
                    continue
                fee_type = cols[1].text.strip()

                # Match "Annual fee Ny"
                if fee_type.startswith("Annual fee") and "y" in fee_type:
                    try:
                        year_str = fee_type.split()[-1].replace("y", "")
                        year_val = int(year_str)
                        max_year = max(max_year, year_val)
                    except:
                        continue

            if max_year == 0:
                due_date = ""
            else:
                # Add max year and get last date of that month
                due_date_raw = filing_date_raw + relativedelta(years=max_year)
                last_day = calendar.monthrange(due_date_raw.year, due_date_raw.month)[1]
                due_date = due_date_raw.replace(day=last_day).strftime("%Y-%m-%dT00:00:00.000Z")

            print("Due Date:", due_date)

        except NoSuchElementException:
            due_date = None
        
        
        # Status (first dd under Patent status)
        try:
            status = driver.find_element(By.XPATH, "//dt[text()='Patent status']/following-sibling::dd[1]").text.strip()
        except:
            status = ""
        

        
        entity = ""
        lawyer = ""
        DE_number = "" 
        application_type = ""
        google_site = ""

        # Extracting the current URL
        PTO_site = driver.current_url

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "FI",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "FI",
            "WEB_SCRAPER_STATUS": False
        }