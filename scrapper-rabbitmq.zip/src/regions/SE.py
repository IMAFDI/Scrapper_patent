from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime
from datetime import datetime, timezone
import re
from bs4 import BeautifulSoup 
import time


# Sweden Region
def scrape_SE(driver, application_number, template_id):

    url = "https://tc.prv.se/spd/search?tab=1&lang=en"
    driver.get(url)

    # region-specific scraping logic for SE
    try:        
        input_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "putfocushere"))
        )
        input_element.clear()
        input_element.send_keys(application_number + Keys.ENTER)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        application_number = application_number
        print(f"Searching for: {application_number}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(5)

        soup = BeautifulSoup(driver.page_source, 'html.parser')

        # Application Number
        # Find the anchor tag by ID or inside the <td headers="applicationno">
        td = soup.find("td", {"headers": "applicationno"})
        if td:
            a_tag = td.find("a")
            if a_tag:
                full_text = a_tag.get_text(strip=True)
                if full_text.startswith("EP"):
                    application_number = full_text.replace("EP", "").strip()

        print("application_number:", application_number)

        # Filled By
        filed_by_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//td[@headers="applicant"]'))
        )

        filled_by_text = filed_by_element.get_attribute("title").strip()
        print(filled_by_text)

        # --- Step 1: Get International Filing Date using Selenium
        try:
            international_filing_date_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="hitlist"]/table/tbody/tr[2]/td[8]'))
            )
            filing_date = international_filing_date_element.text.strip() + "T00:00:00.000Z"
        except NoSuchElementException:
            filing_date = None

        print("🌍 International Filing Date:", filing_date)

        # Wait for the anchor tag to be present and clickable
        wait = WebDriverWait(driver, 10)
        anchor_element = wait.until(EC.element_to_be_clickable((By.ID, "putfocushere")))

        # Click on the anchor tag
        anchor_element.click()

        print("✅ Anchor tag clicked successfully!")

        time.sleep(5)

        #grant number
        try:
            grant_number_element = driver.find_element(By.XPATH, '//*[@id="bold_first_td"]/tbody/tr[2]/td[2]')
            grant_number_raw = grant_number_element.text.strip()
            grant_number = grant_number_raw.replace("EP ", "EP")
            print(grant_number)
        except NoSuchElementException:
            grant_number = ""
        
        #Title
        try:
            title_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, 'padme'))
            )
            title = title_element.text.strip()
        except NoSuchElementException:
            title = ""

        # Grant Date
        try:
            grant_date_element = driver.find_element(By.XPATH, '//td[text()="Grant date EPO:"]/following-sibling::td[@class="datevalue"]')
            grant_date = grant_date_element.text.strip() + "T00:00:00.000Z"
            print(grant_date)
        except NoSuchElementException:
            grant_date = None

        

        # --- Step 2: Get Page Source and parse with BeautifulSoup
        html = driver.page_source
        soup = BeautifulSoup(html, 'html.parser')

        # --- Step 3: Extract 'Next annual fee' date
        due_date = None
        rows = soup.find_all("tr")

        for row in rows:
            cells = row.find_all("td")
            if len(cells) >= 2:
                key = cells[0].get_text(strip=True).replace("\xa0", " ").lower()
                if "next annual fee" in key:
                    raw_date = cells[1].get_text(strip=True)
                    print("📅 Raw Date Found:", raw_date)

                    # Try parsing known formats
                    try:
                        due_dt = datetime.strptime(raw_date, "%Y-%m-%d")  # e.g., 2025-09-30
                    except ValueError:
                        try:
                            due_dt = datetime.strptime(raw_date, "%d.%m.%Y")  # fallback: 30.09.2025
                        except ValueError as e:
                            print("❌ Failed to parse date:", e)
                            due_dt = None

                    if due_dt:
                        due_date = due_dt.strftime("%Y-%m-%dT00:00:00.000Z")
                    break

        print("✅ Due Date:", due_date)

        # Status
        status_element = driver.find_element(By.XPATH, '//*[@id="main"]/table[2]/tbody/tr[3]/td[2]')
        status = status_element.text.strip()
        print(status)

        # Lawyer
        try:
            lawyer_name = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//td[normalize-space(text())="SE Representative:"]/following-sibling::td[@class="padme"]/ul/li'))
            )
            lawyer_element = lawyer_name.text.strip()
            lawyer = lawyer_element.split(",")[0].strip()
        except Exception as e:
            print(f"Lawyer not found: {e}")
            lawyer = ""
        
        entity = ""
        DE_number = "" 
        application_type = ""
        google_site = ""

        # Extracting the current URL
        PTO_site = driver.current_url

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "SE",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "SE",
            "WEB_SCRAPER_STATUS": False
        }