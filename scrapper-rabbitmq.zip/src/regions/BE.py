from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from dateutil.relativedelta import relativedelta
from datetime import datetime
from datetime import datetime, timezone
import calendar
import time


# Belgium Region
def scrape_BE(driver, application_number, template_id):

    url = "https://bpp.economie.fgov.be/fo-eregister-view/search"
    driver.get(url)

    # region-specific scraping logic for BE
    try:
        # remove dot
        app_no = application_number.replace(".", "")
        # Ensure application number starts with "BE"
        if not app_no.upper().startswith("BE"):
            app_no = "BE" + app_no
        
        input_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.NAME, "number"))
        )
        input_element.clear()
        input_element.send_keys(app_no + Keys.ENTER)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        print(f"Searching for: {app_no}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        # Application Number
        application_no_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="tt"]/div[2]/div[1]/div/dl[1]/dd[1]'))
        )
        raw_app_number = application_no_element.text.strip()

        # Insert dot before the last digit
        if raw_app_number.isdigit() and len(raw_app_number) > 1:
            application_number = raw_app_number[:-1] + '.' + raw_app_number[-1]
        else:
            application_number = raw_app_number  # fallback if format is unexpected

        #grant
        try:    
            grant_element = driver.find_element(By.XPATH, '//*[@id="tt"]/div[2]/div[1]/div/dl[2]/dd[1]')
            grant_number_raw = grant_element.text.strip()
            grant_number = f"EP{grant_number_raw}"

        except NoSuchElementException:
            grant_number = ""
        
        #title
        title_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, 'PatentTitle'))
        )

        # Find all <strong> elements inside it
        strong_elements = title_element.find_elements(By.TAG_NAME, 'strong')

        # Extract second <strong> text (patent title)
        if len(strong_elements) >= 2:
            title = strong_elements[1].text.strip()
            print("Title:", title)
        else:
            print("Title not found.")
        
        entity = ""

        # Filed By
        filed_by_element = driver.find_element(By.XPATH, '//*[@id="tt"]/div[2]/div[1]/div/dl[5]/dd[1]')
        filled_by_text = filed_by_element.text.strip()

        # International Filing Date
        try:
            international_filing_date_element = driver.find_element(By.XPATH, '//*[@id="tt"]/div[2]/div[1]/div/dl[3]/dd[1]')
            international_filing_date_raw = international_filing_date_element.text.strip()
            parsed_date = datetime.strptime(international_filing_date_raw, "%d/%m/%Y")
            filing_date = parsed_date.strftime("%Y-%m-%dT00:00:00.000Z")
        except:
            filing_date = None

        # Grant Date
        try:
            grant_date_element = driver.find_element(By.XPATH, '//*[@id="tt"]/div[2]/div[1]/div/dl[3]/dd[2]')
            grant_date_raw = grant_date_element.text.strip()
            parsed_grant_date = datetime.strptime(grant_date_raw, "%d/%m/%Y")
            grant_date = parsed_grant_date.strftime("%Y-%m-%dT00:00:00.000Z")
        except:
            grant_date = None

        # DUE DATE CALCULATION
        due_date = None  # Default

        try:
            # Locate the correct <dl> block (RightCol fee info)
            dl_elements = driver.find_elements(By.XPATH, "//dl[contains(@class, 'Grid') and contains(@class, 'RightCol')]")

            for dl in dl_elements:
                dt_elements = dl.find_elements(By.TAG_NAME, "dt")
                dd_elements = dl.find_elements(By.TAG_NAME, "dd")

                for dt, dd in zip(dt_elements, dd_elements):
                    label = dt.text.strip().lower()
                    value = dd.text.strip()

                    if "last annual fee paid number" in label:
                        try:
                            fee_years = int(value)
                        except:
                            fee_years = None
                        break
                else:
                    fee_years = None  # If not found, fallback
        except:
            fee_years = None

        # Calculate Due Date
        try:
            if filing_date:
                filing_date_obj = datetime.strptime(filing_date[:10], "%Y-%m-%d")
                due_date_obj = filing_date_obj + relativedelta(years=fee_years)
                last_day = calendar.monthrange(due_date_obj.year, due_date_obj.month)[1]
                due_date_obj = due_date_obj.replace(day=last_day)
                due_date = due_date_obj.strftime("%Y-%m-%dT00:00:00.000Z")
                print(due_date)
        except:
            due_date = None


        

        #lawyer
        lawyer = ""  # Default fallback as string

        try:
            # Get all <dl> elements with class containing both 'Grid' and 'RightCol'
            dl_elements = driver.find_elements(By.XPATH, "//dl[contains(@class, 'Grid') and contains(@class, 'RightCol')]")

            for dl in dl_elements:
                dt_elements = dl.find_elements(By.TAG_NAME, "dt")
                dd_elements = dl.find_elements(By.TAG_NAME, "dd")

                # Safely pair <dt> and <dd>
                for dt, dd in zip(dt_elements, dd_elements):
                    dt_text = dt.text.strip().lower().replace(":", "")
                    dd_text = dd.text.strip()

                    if "payer" in dt_text:
                        lawyer = dd_text
                        break

                if lawyer != "":
                    break  # Stop if found

        except Exception as e:
            print("Error during lawyer extraction:", e)
            lawyer = ""  # fallback

        print("Lawyer:", lawyer)


        
        DE_number = ""

        #status
        try:
            status_element = driver.find_element(By.XPATH, '//*[@id="tt"]/div[2]/div[1]/div/dl[1]/dd[4]')
            status = status_element.text.strip()
        except NoSuchElementException:
            status = ""
         
        application_type = ""
        google_site = ""

        # Extracting the current URL
        PTO_site = driver.current_url

        # Final Application Number
        application_number = application_number

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "BE",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "BE",
            "WEB_SCRAPER_STATUS": False
        }