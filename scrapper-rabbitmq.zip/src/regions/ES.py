from datetime import datetime
from datetime import datetime, timezone
import calendar
import re
import time
from bs4 import BeautifulSoup

# Spain Region
def scrape_ES(driver, application_number, template_id):

    # Remove decimal part if present
    application_number = application_number.split(".")[0].strip() 

    # application_number = application_number.split(".")[0]
    if not application_number.upper().startswith("E"):
            application_number = "E" + application_number
    
    url = f"https://consultas2.oepm.es/ceo/jsp/busqueda/consultaExterna.xhtml?numExp={application_number}"
    driver.get(url)

    # region-specific scraping logic for ES
    try:
        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        print(f"Searching for: {application_number}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        html = driver.page_source
        soup = BeautifulSoup(html, 'html.parser')

        # Initialize all values
        filing_date = grant_date = None
        entity = DE_number = ""  # Always empty per spec

        # Helper function to format date
        def format_date(d):
            try:
                return datetime.strptime(d.strip(), "%d/%m/%Y").strftime("%Y-%m-%dT00:00:00.000Z")
            except:
                return None

        # 8. Application Number
        app_no_tag = soup.find("h4", string=lambda t: t and "Application No." in t)
        if app_no_tag:
            raw_app_no = app_no_tag.find_next("p").get_text(strip=True)
            application_number = raw_app_no.replace("E", "").strip()
        else:
            application_number = ""

        # 1. Grant number
        grant_tag = soup.find("h4", text=lambda t: t and "EPO publication number" in t)
        if grant_tag:
            grant_number = grant_tag.find_next("p").get_text(strip=True)

        # 2. Title
        title_tag = soup.find("h4", text="Title:")
        if title_tag:
            title = title_tag.find_next("p").get_text(strip=True)

        # 3. Filing Date
        filing_tag = soup.find("h4", text=lambda t: t and "Filing date" in t)
        if filing_tag:
            filing_date = format_date(filing_tag.find_next("p").get_text())

        # 4. Grant Date
        grant_date_tag = soup.find("h4", string=lambda t: t and "Grant publication date" in t.strip())
        if grant_date_tag:
            grant_date_text = grant_date_tag.find_next("p").get_text(strip=True)
            grant_date = format_date(grant_date_text)
        
        # Due Date

        # Step 1: Parse international filing date
        filing_dt = datetime.strptime(filing_date.split("T")[0], "%Y-%m-%d")

        # Step 2: Find the <h4> with "Payments"
        payments_h4 = soup.find("h4", string=lambda t: t and "Payments" in t)
        due_date = None

        if payments_h4:
            payments_table = payments_h4.find_next("table")
            if payments_table:
                first_row = payments_table.find("tbody").find("tr")
                if first_row:
                    cells = first_row.find_all("td")
                    if len(cells) >= 2:
                        payment_text = cells[1].get_text(strip=True)

                        # Step 3: Extract the year number from "Pago XX Anualidad"
                        match = re.search(r"Pago\s+(\d{1,2})\s+Anualidad", payment_text)
                        if match:
                            year_offset = int(match.group(1))

                            # Step 4: Calculate new date
                            due_year = filing_dt.year + year_offset
                            due_month = filing_dt.month
                            last_day = calendar.monthrange(due_year, due_month)[1]
                            due_dt = datetime(due_year, due_month, last_day)

                            # Step 5: Format as ISO
                            due_date = due_dt.strftime("%Y-%m-%dT00:00:00.000Z")

        print("📅 Calculated Due Date:", due_date)


        # 5. Filled By (Applicant Name)
        filled_name_tag = soup.find("span", string="Name:")
        if filled_name_tag:
            raw_name = filled_name_tag.find_next("div", class_="divRight").get_text(strip=True)
            filled_by_text = raw_name.split('(')[0].strip()

        # 6. Lawyer (Agent Name)
        lawyer_tag = soup.find("span", string="Name:")
        if lawyer_tag:
            for parent in lawyer_tag.parents:
                if parent.find("h4", string="Agent:"):
                    lawyer = lawyer_tag.find_next("div", class_="divRight").get_text(strip=True)
                    break

        # 7. Status
        status_tag = soup.find("h4", text="Status:")
        if status_tag:
            status = status_tag.find_next("p").get_text(strip=True)
        
        
        entity = ""
        DE_number = "" 
        application_type = ""
        google_site = ""

        # Extracting the current URL
        PTO_site = driver.current_url

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "ES",
            "granT_NUMBER": grant_number,
            "title" : title,
            "entity_size": entity,
            "fileD_BY": filled_by_text,
            "international_filing_date": filing_date,
            "grant_date": grant_date,
            "due_date": due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "ES",
            "WEB_SCRAPER_STATUS": False
        }