from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from dateutil.relativedelta import relativedelta
from seleniumbase import Driver
from fake_useragent import UserAgent
from datetime import datetime
from datetime import datetime, timedelta, timezone
from urllib.parse import quote
import calendar
import re
import time
import json
import requests
from bs4 import BeautifulSoup
import urllib


# Croatia Region
def scrape_HR(application_number, template_id):

    # Normalize application number to EP######## format
    application_number_clean = application_number.upper().replace("EP", "").replace("E", "").split('.')[0]
    app_no = "EP" + application_number_clean


    driver = Driver(uc =True)
    url = f"https://register.epo.org/application?number={app_no}"
    print(url)
    driver.uc_open_with_reconnect(url, 4)

    # region specific logic for HR
    try: 
        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        print(f"Searching for: {app_no}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        # Click on Legal Status
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "epoContentNav"))
        )

        # Find and click the "EP Legal status" link
        legal_status_link = driver.find_element(By.XPATH, "//a[contains(text(),'EP Legal status')]")
        print("🔗 Clicking on: EP Legal status")
        legal_status_link.click()

        # Wait 5 seconds on the new page
        print("⏳ Waiting 5 seconds on Legal status page...")
        time.sleep(5)

        # Now click on HR Link
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "ext"))
        )

        # Find the <a> tag with text "HR" and click it
        tr_link = driver.find_element(By.XPATH, "//a[@class='ext' and text()='HR']")
        tr_url = tr_link.get_attribute("href")
        print(f"🔗 Found HR link: {tr_url}")

        # Navigate to the Croatia patent register link
        driver.get(tr_url)

        # Wait on that page for 5 seconds
        print("⏳ Waiting 5 seconds on Croatia site...")
        time.sleep(5)

        # Scrapping Value

        def format_date(date_str):
            try:
                return datetime.strptime(date_str.strip(), "%d.%m.%Y").strftime("%Y-%m-%dT00:00:00.000Z")
            except:
                return None

        # Load your HTML here
        soup = BeautifulSoup(driver.page_source, "html.parser")  # use your HTML string or driver.page_source

        # Helper: find <td> by label text
        def find_td_with_label(label):
            return soup.find('td', class_='drugiStupac', string=lambda s: s and label in s)

        # Extract application_number and filing_date
        row_96 = find_td_with_label("Number of the European patent application:")
        if row_96:
            val_96 = row_96.find_next_sibling('td').get_text(strip=True)
            parts = val_96.split(",")
            application_number = parts[0].strip()
            filing_date = format_date(parts[1].strip()) if len(parts) > 1 else None
        else:
            application_number = ""
            filing_date = None

        # Extract grant_number and grant_date
        row_97 = find_td_with_label("Publication data of the European patent:")
        if row_97:
            val_97 = row_97.find_next_sibling('td').get_text(strip=True)
            parts = val_97.split(",")
            grant_number = parts[0].strip()
            grant_date = format_date(parts[1].strip()) if len(parts) > 1 else None
        else:
            grant_number = ""
            grant_date = None

        # Extract title
        title = ""
        row_title = find_td_with_label("English Title:")
        title = row_title.find_next_sibling('td').get_text(strip=True) if row_title else None

        # Extract filled_by_text
        row_holder = find_td_with_label("Holder(s):")
        filled_by_text = ""
        if row_holder:
            table = row_holder.find_next_sibling('td').find('table')
            if table:
                filled_by_text = table.get_text(strip=True)

        # Extract lawyer
        lawyer = ""
        row_lawyer = find_td_with_label("Representative:")
        lawyer = row_lawyer.find_next_sibling('td').get_text(strip=True) if row_lawyer else None

        # Extract due_date
        row_due = find_td_with_label("Annual fee:")
        due_date_text = row_due.find_next_sibling('td').get_text(strip=True) if row_due else None
        due_date = None
        if due_date_text:
            due_date_match = due_date_text.split(" for ")[0].strip()
            due_date = format_date(due_date_match)

        # Extract status
        row_status = soup.find('td', string=lambda s: s and "Registration Number:" in s)
        status = ""
        if row_status:
            status_td = row_status.find_next('td', width="60%")
            if status_td:
                text = status_td.get_text(strip=True)
                if "(" in text and ")" in text:
                    status = text[text.find("(")+1:text.find(")")].strip()

        

        entity = ""
        DE_number = ""
        application_type = ""
        google_site = ""
        

        # Extracting the current URL
        PTO_site = driver.current_url

        # ✅ Close the driver once scraping is done
        driver.quit()

        # Check if due_date or filing_date or entity is missing
        if filing_date is None or due_date is None:
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "HR",
                "WEB_SCRAPER_STATUS": False
            }  

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "HR",
            "granT_NUMBER": grant_number,
            "title" : title,
            "entity_size": entity,
            "fileD_BY": filled_by_text,
            "international_filing_date": filing_date,
            "grant_date": grant_date,
            "due_date": due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        try:
            driver.quit()
        except:
            pass
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "HR",
            "WEB_SCRAPER_STATUS": False
        }