from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from dateutil.relativedelta import relativedelta
from seleniumbase import Driver
from datetime import datetime
from datetime import datetime, timezone
import calendar
import re
import time
from bs4 import BeautifulSoup

# Hungary Region
def scrape_HU(application_number, template_id):

    # Normalize application number to EP######## format
    application_number_clean = application_number.upper().replace("EP", "").replace("E", "").split('.')[0]
    app_no = "EP" + application_number_clean


    driver = Driver(uc =True)
    url = f"https://register.epo.org/application?number={app_no}"
    print(url)
    driver.uc_open_with_reconnect(url, 4)

    # region specific logic for HU
    try: 
        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        print(f"Searching for: {app_no}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        # Click on Legal Status
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "epoContentNav"))
        )

        # Find and click the "EP Legal status" link
        legal_status_link = driver.find_element(By.XPATH, "//a[contains(text(),'EP Legal status')]")
        print("🔗 Clicking on: EP Legal status")
        legal_status_link.click()

        # Wait 5 seconds on the new page
        print("⏳ Waiting 5 seconds on Legal status page...")
        time.sleep(5)

        # Now click on HU Link
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "ext"))
        )

        # Find the <a> tag with text "HU" and click it
        tr_link = driver.find_element(By.XPATH, "//a[@class='ext' and text()='HU']")
        tr_url = tr_link.get_attribute("href")
        print(f"🔗 Found HU link: {tr_url}")

        # Navigate to the Hungary patent register link
        driver.get(tr_url)

        # Wait on that page for 5 seconds
        print("⏳ Waiting 5 seconds on Hungary site...")
        time.sleep(5)

        # Function to convert DD/MM/YYYY → YYYY-MM-DDT00:00:00.000Z
        def convert_to_iso(date_str):
            try:
                dt = datetime.strptime(date_str, "%d-%m-%Y")
                return dt.strftime("%Y-%m-%dT00:00:00.000Z")
            except:
                return ""

        soup = BeautifulSoup(driver.page_source, "html.parser")

        # Helper function to extract next cell text from a row
        def extract_text_after_label(label_text):
            tag = soup.find('span', string=re.compile(label_text, re.I))
            if tag:
                parent_td = tag.find_parent('td')
                if parent_td and parent_td.find_next_sibling('td'):
                    return parent_td.find_next_sibling('td').get_text(strip=True)
            return ""

        # Extract application number (last value in top-right corner table)
        application_number = soup.find('a', href=re.compile(r'register.epo.org')).get_text(strip=True)
        print(application_number)

        # Extract grant number (EP2493508B1) and trim to base
        grant_number_full = extract_text_after_label("European Patent Granted")
        grant_number = extract_text_after_label("- Number") if grant_number_full == "" else grant_number_full
        grant_number = re.match(r'(EP\d+)', grant_number).group(1) if grant_number else ""

        # Extract title
        title = extract_text_after_label("Title of patent")

        # Extract rightholder
        # filled_by_text = extract_text_after_label("Rightholder")

        filled_by_raw = extract_text_after_label("Rightholder")

        # Split by semicolon to separate name and address components
        parts = filled_by_raw.split(';')

        # Build list of cleaned names
        names = []
        for part in parts:
            # Remove (100%) or similar percentage indicators
            cleaned = re.sub(r'\(\d+%\)', '', part).strip()
            # Take only the portion before digits or comma (likely the name)
            name_only = re.split(r'\d{2,}|,', cleaned)[0].strip()
            if name_only:
                names.append(name_only)

        filled_by_text = ", ".join(names)


        # Entity is not mentioned, so use blank
        entity = ""

        # Extract filing date
        filing_info = extract_text_after_label("European patent application, filing date, application number")
        filing_date_match = re.match(r'(\d{4}\.\d{2}\.\d{2})', filing_info)
        if filing_date_match:
            filing_date_raw = filing_date_match.group(1)
            try:
                filing_date = datetime.strptime(filing_date_raw, "%Y.%m.%d").strftime("%Y-%m-%dT00:00:00.000Z")
            except:
                filing_date = None
        else:
            filing_date = None

        # Extract grant date
        grant_date_raw = extract_text_after_label("- Date")
        try:
            grant_date = datetime.strptime(grant_date_raw.strip(), "%Y.%m.%d").strftime("%Y-%m-%dT00:00:00.000Z")
        except:
            grant_date = None

        # Extract lawyer/representative
        lawyer = extract_text_after_label("Representative")

        # Extract status
        status_raw = soup.find('span', string="Under protection")
        status = status_raw.get_text(strip=True) if status_raw else ""

        # Due Date

        # Step 1: Click on the "e-register (Hungarian only)" button
        button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//input[@value=" e-register (Hungarian only) "]'))
        )
        button.click()

        # Step 2: Wait for new tab to open and switch to it
        time.sleep(1)  # Give a moment for tab to appear
        tabs = driver.window_handles
        driver.switch_to.window(tabs[-1])  # Switch to new tab

        # Step 3: Wait 5 seconds for content to load
        time.sleep(5)

        soup = BeautifulSoup(driver.page_source, 'html.parser')
        
        international_filing_date_obj = datetime.strptime(filing_date, "%Y-%m-%dT%H:%M:%S.%fZ")

        # Step 4. Find "Fenntartási díjak" section
        fenntartas_section = soup.find('span', string=re.compile("Fenntartási díjak", re.I))
        if fenntartas_section:
            # Go through next siblings to find all "Érvényesség" entries
            validity_years = []
            for table in fenntartas_section.find_all_next('table'):
                if "Érvényesség" in table.get_text():
                    continue  # this is the header row
                for td in table.find_all('td'):
                    text = td.get_text(strip=True)
                    match = re.match(r'(\d+)\s*\(', text)
                    if match:
                        validity_years.append(int(match.group(1)))
                if 'Egyéb intézkedések' in table.get_text():
                    break  # Stop once next major section starts

            max_years = max(validity_years) if validity_years else 0

            # Step 5. Add max_years to filing date
            final_due_date_obj = international_filing_date_obj + relativedelta(years=max_years)

            # Step 6. Get last day of that month
            last_day = calendar.monthrange(final_due_date_obj.year, final_due_date_obj.month)[1]
            due_date = final_due_date_obj.replace(day=last_day).strftime("%Y-%m-%dT00:00:00.000Z")

        else:
            due_date = None

        print("due_date:", due_date)
        

        entity = ""
        DE_number = ""
        application_type = ""
        google_site = ""
        

        # Extracting the current URL
        PTO_site = driver.current_url

        # ✅ Close the driver once scraping is done
        driver.quit()

        # Check if due_date or filing_date or entity is missing
        if filing_date is None or due_date is None:
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "wheN_RUN": when_run,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "HU",
                "WEB_SCRAPER_STATUS": False
            }  

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "HU",
            "granT_NUMBER": grant_number,
            "title" : title,
            "entity_size": entity,
            "fileD_BY": filled_by_text,
            "international_filing_date": filing_date,
            "grant_date": grant_date,
            "due_date": due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        try:
            driver.quit()  # Make sure driver still closes on error
        except:
            pass
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "HU",
            "WEB_SCRAPER_STATUS": False
        }