from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
from datetime import datetime, timezone
from urllib.parse import quote
import calendar
import re
import time
from bs4 import BeautifulSoup

# Denmark Region
def scrape_DK(driver, application_number, template_id):

    app_no = quote(application_number)
    url = f"https://onlineweb.dkpto.dk/pvsonline/Patent?action=102&language=gb&sagID={app_no}"
    driver.get(url)

    # region specific logic for DK
    try: 
        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        print(f"Searching for: {app_no}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        soup = BeautifulSoup(driver.page_source, "html.parser")

        def extract_value_by_label(label_text):
            rows = soup.select("table.FanePanel tr")
            for row in rows:
                tds = row.find_all('td')
                if len(tds) >= 2 and label_text.lower() in tds[0].get_text(strip=True).lower():
                    return tds[1].get_text(strip=True)
            return None

        grant_number_raw = extract_value_by_label("EP pub. no. and date")
        grant_number = " ".join(grant_number_raw.split()[:2]) if grant_number_raw else None

        title = extract_value_by_label("Title")

        filed_by_raw = extract_value_by_label("Applicant/owner")
        filled_by_text = filed_by_raw.split(',')[0].strip() if filed_by_raw else None

        # Format EPO date string to ISO format
        def format_epo_date(date_str):
            try:
                dt = datetime.strptime(date_str.strip(), "%Y%m%d")
                return dt.strftime("%Y-%m-%dT00:00:00.000Z")
            except:
                return date_str  # return original if format is invalid

        # Extract filing date
        international_filing_raw = extract_value_by_label("Application no. and date")
        filing_date = None
        if international_filing_raw:
            raw_date = international_filing_raw.split(',')[-1].strip()
            filing_date = format_epo_date(raw_date)

        # Extract grant date
        grant_date_raw = extract_value_by_label("Publication date")
        grant_date = format_epo_date(grant_date_raw.strip()) if grant_date_raw else None


        lawyer_raw = extract_value_by_label("Representative")
        lawyer = lawyer_raw.split(',')[0].strip() if lawyer_raw else None

        time.sleep(3)

        # Step 1: Click Økonomi tab
        try:
            okonomi_tab = WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "a[href*='action=103']"))
            )
            okonomi_tab.click()
            print("✅ Clicked Økonomi tab successfully.")
        except Exception as e:
            print("❌ Error clicking Økonomi tab:", str(e))

        time.sleep(3)  # Let the new page/tab load

        filing_dt = datetime.strptime(filing_date, "%Y-%m-%dT00:00:00.000Z")
        current_year = datetime.now().year

        # --- Parse Økonomi table ---
        html = driver.page_source  # After Økonomi tab is loaded
        soup = BeautifulSoup(html, 'html.parser')
        rows = soup.find_all('tr', class_='zebra')

        due_date = None

        for row in rows:
            cols = row.find_all('td')
            if len(cols) >= 5:
                desc = cols[4].get_text(strip=True)

                # Case 1: range pattern like "1.-3. gebyrår"
                match_range = re.search(r"(\d+)\.-(\d+)\. gebyrår", desc)
                if match_range:
                    year_start = int(match_range.group(1))
                    year_end = int(match_range.group(2))
                    offset_years = (year_start + year_end) // 2 - 1  # take average and subtract 1
                    print(f"Matched range year: {year_start}-{year_end}, offset: {offset_years}")
                
                # Case 2: single year like "9. gebyrår"
                else:
                    match_single = re.search(r"(\d+)\. gebyrår", desc)
                    if match_single:
                        offset_years = int(match_single.group(1)) - 1
                        print(f"Matched single year: {match_single.group(1)}, offset: {offset_years}")
                    else:
                        continue  # Skip if no valid year pattern found

                # Compute due date from offset
                target_year = filing_dt.year + offset_years
                target_month = filing_dt.month
                last_day = calendar.monthrange(target_year, target_month)[1]
                due_date_dt = datetime(target_year, target_month, last_day)
                due_date = due_date_dt.strftime("%Y-%m-%dT00:00:00.000Z")
                break
        
        print("FInal Due Date :", due_date)

        entity = ""
        DE_number = ""
        application_type = ""
        google_site = ""
        status = ""

        # Extracting the current URL
        PTO_site = driver.current_url

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "DK",
            "granT_NUMBER": grant_number,
            "title" : title,
            "entity_size": entity,
            "fileD_BY": filled_by_text,
            "international_filing_date": filing_date,
            "grant_date": grant_date,
            "due_date": due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "DK",
            "WEB_SCRAPER_STATUS": False
        }