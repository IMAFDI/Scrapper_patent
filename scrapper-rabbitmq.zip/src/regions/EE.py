from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime
from datetime import datetime, timezone
import time
from bs4 import BeautifulSoup

# Estonia Region
def scrape_EE(driver, application_number, template_id):

    # Normalize application number to EP######## format
    application_number_clean = application_number.upper().replace("EP", "").replace("E", "")
    app_no = "EP" + application_number_clean

    url = f"https://www1.epa.ee/ep/data.asp?NroParam={app_no}"
    driver.get(url)

    # region specific logic for EE
    try: 
        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        print(f"Searching for: {app_no}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        def format_date(date_str):
            """Convert 'dd.mm.yyyy' to 'yyyy-mm-ddT00:00:00.000Z'"""
            try:
                return datetime.strptime(date_str.strip(), "%d.%m.%Y").strftime("%Y-%m-%dT00:00:00.000Z")
            except:
                return ""

        # Load your HTML here
        soup = BeautifulSoup(driver.page_source, "html.parser")  # use your HTML string or driver.page_source

        def extract_by_label(label_text):
            cell = soup.find('td', string=lambda s: s and label_text in s)
            if cell:
                return cell.find_next_sibling('td').get_text(strip=True).replace('\xa0', ' ')
            return ""

        application_number = extract_by_label("Application number")

        # Grant Number
        try:
            grant_number = extract_by_label("European Patent number")
        except NoSuchElementException:
            grant_number = ""

        # Title
        try:
            title = extract_by_label("Estonian title")
        except NoSuchElementException:
            title = ""

        # Filed By
        try:
            filled_by_text = extract_by_label("Owner")
        except NoSuchElementException:
            filled_by_text = ""

        # International Filing Date
        try :
            filing_date = format_date(extract_by_label("Filing date of the application"))
        except NoSuchElementException:
            filing_date = None

        # Grant Date
        try:    
            grant_date = format_date(extract_by_label("Date of the grant of the European patent"))
        except NoSuchElementException:
            grant_date = None
        
        # Lawyer
        try:
            lawyer = extract_by_label("Patent attorney")
        except NoSuchElementException:
            lawyer = ""
        
        # Status
        try:
            status = extract_by_label("Status")
        except NoSuchElementException:
            status = ""    

        # Due Date
        # Step 1: Click on "DATA OF THE FEES" link
        fees_link = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.LINK_TEXT, "DATA OF THE FEES"))
        )
        fees_link.click()

        # Step 2: Wait for the new page to load
        time.sleep(5)

        # Optional: Now parse the updated page with BeautifulSoup
        soup = BeautifulSoup(driver.page_source, 'html.parser')

        # Assuming `soup` is already initialized with the page's HTML
        due_date = None

        # Find the row with "Deadline for next payment:"
        row = soup.find('td', string=lambda text: text and "Deadline for next payment" in text)
        if row:
            due_date_td = row.find_next_sibling('td')
            if due_date_td:
                raw_date = due_date_td.get_text(strip=True)
                try:
                    due_date = datetime.strptime(raw_date, "%d.%m.%Y").strftime("%Y-%m-%dT00:00:00.000Z")
                except:
                    due_date = ""

        print("due_date:", due_date)

        entity = ""
        DE_number = ""
        application_type = ""
        google_site = ""
        

        # Extracting the current URL
        PTO_site = driver.current_url

        # Check if due_date or filing_date or entity is missing
        if filing_date is None or due_date is None:
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "wheN_RUN": when_run,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "EE",
                "WEB_SCRAPER_STATUS": False
            }  

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "EE",
            "granT_NUMBER": grant_number,
            "title" : title,
            "entity_size": entity,
            "fileD_BY": filled_by_text,
            "international_filing_date": filing_date,
            "grant_date": grant_date,
            "due_date": due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "EE",
            "WEB_SCRAPER_STATUS": False
        }