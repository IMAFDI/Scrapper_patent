from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime
from datetime import datetime, timezone

#Function Defination for NewZealand scraping
def scrape_NZ(driver, application_number, template_id):
    url = "https://app.iponz.govt.nz/app/Extra/IP/PT/Qbe.aspx?sid=638810364622264112&op=EXTRA_pt_qbe&fcoOp=EXTRA__Default&directAccess=true"
    driver.get(url)

    # region-specific scraping logic for NZ
    try:
        input_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.NAME, "ctl00$MainContent$ctrlPTSearch$txtGtNr"))
        )
        input_element.clear()
        input_element.send_keys(application_number + Keys.ENTER)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        application_number = application_number
        grant_number = ""
        print(f"Searching for: {application_number}")
        print("-" * 20)

        #title extraction
        try:
            title_element = WebDriverWait(driver, 10).until(
                    EC.text_to_be_present_in_element((By.ID, "lblTitle"), " - ")  # Wait until the text has ' - ' which means it's the full title
            )

            # Now fetch the element
            title_element = driver.find_element(By.ID, "lblTitle")
            full_title = title_element.text.strip()
            title = full_title.split(' - ')[-1]

        except NoSuchElementException:
            title = ""
        
        entity = ""
    
        #filled by
        try:    
            filled_by_element = driver.find_element(By.XPATH, '//*[@id="MainContent_ctrlPT_ctrlApplicant_UpdatePanel1"]/table/tbody/tr[1]/td[2]/div[2]/table/tbody/tr[3]/td[2]')
            filled_by_text = filled_by_element.text.strip()

        except NoSuchElementException:
            filled_by_text = ""


        # international filing date
        try:
            filing_date_element = driver.find_element(By.XPATH, '//*[@id="MainContent_ctrlPT_trFilingDate"]/td[2]')
            filing_date_raw = filing_date_element.text.strip()

            # Convert from "10 Aug 2021" to datetime object
            filing_date = f"{datetime.strptime(filing_date_raw, '%d %b %Y').strftime('%Y-%m-%d')}T00:00:00.000Z"

        except NoSuchElementException:
            filing_date = None

        grant_date = None

        #due date
        try:
            due_date_element = driver.find_element(By.XPATH, '//*[@id="MainContent_ctrlPT_trDtOPI"]/td[2]')
            due_date_raw = due_date_element.text.strip()

            if not due_date_raw:
                # Try alternative XPath if the first one is blank
                due_date_element_alt = driver.find_element(By.XPATH, '//*[@id="MainContent_ctrlPT_trDtLapseDtExpiration"]/td[4]')
                due_date_raw = due_date_element_alt.text.strip()

            if due_date_raw:
                # Parse date
                due_date = f"{datetime.strptime(due_date_raw, '%d %b %Y').strftime('%Y-%m-%d')}T00:00:00.000Z"


            else:
                due_date = None

        except NoSuchElementException:
            due_date = None

        lawyer = ""
        DE_number = ""

        #status
        try:
            status_element = driver.find_element(By.ID, 'MainContent_ctrlPT_lblCurrentStatus')
            status = status_element.text.strip()
        except NoSuchElementException:
            status = ""
         
        application_type = ""
        google_site = ""

        # Extracting the current URL
        PTO_site = driver.current_url

        # Check if due_date or filing_date or entity is missing
        if filing_date is None or due_date is None:
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "wheN_RUN": when_run,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "NZ",
                "WEB_SCRAPER_STATUS": False
            }       


        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "NZ",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }

    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "NZ",
            "WEB_SCRAPER_STATUS": False
        }
