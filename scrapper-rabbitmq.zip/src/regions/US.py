from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from datetime import datetime
from datetime import datetime, timedelta, timezone
import re

#Function Defination for US scraping
def scrape_US(driver, application_number, google_patent_url, template_id):
    driver.get(google_patent_url)
    try:
        print(f"Searching for: {application_number}")
        print("-" * 20)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        
        try:
            application_number_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="wrapper"]/div[1]/div[2]/section/application-timeline/div/div[3]'))
            )
            application_number = application_number_element.text.strip()
            match = re.search(r'US(\d+/\d+,\d+)', application_number)
            if match:
                application_number = match.group(1)
        except NoSuchElementException:
            application_number = ""

        #grant number extraction
        try:
            grant_number_element = driver.find_element(By.XPATH, '//*[@id="pubnum"]')
            grant_number = grant_number_element.text.strip()[2:-2]

        except NoSuchElementException:
            grant_number = ""
        

        #title extraction
        try:
            full_title = driver.execute_script('return document.title;')

            # Extract only the part after the hyphen (assuming the title format is consistent)
            title_parts = full_title.split(' - ')
            if len(title_parts) > 1:
                title = title_parts[1].strip()  # This will be "Portable seat cushion"
            else:
                title = full_title.strip()

        except NoSuchElementException:
            title = ""

    
        # filled by
        try:
            filed_by_raw = driver.find_element(By.XPATH, "//span[contains(text(), 'Application filed by')]").text
            filled_by_text = filed_by_raw.replace("Application filed by ", "").strip()
        except NoSuchElementException:
            filled_by_text = ""


        # international filing date
        try:
            filing_date_element = driver.find_element(By.XPATH, '//*[@id="wrapper"]/div[1]/div[2]/section/application-timeline/div/div[4]/div[1]')
            filing_date_raw = filing_date_element.text.strip()

            try:
                # Try parsing common formats
                try:
                    date_obj = f"{datetime.strptime(filing_date_raw, '%d %b %Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
                except ValueError:
                    date_obj = f"{datetime.strptime(filing_date_raw, '%Y-%m-%d').strftime('%Y-%m-%d')}T00:00:00.000Z"

                filing_date = date_obj

                # # Add current UTC time
                # now = datetime.now(timezone.utc)
                # date_obj = date_obj.replace(
                #     hour=now.hour, minute=now.minute, second=now.second,
                #     microsecond=now.microsecond, tzinfo=timezone.utc
                # )

                # # Format to ISO 8601 with milliseconds and 'Z'
                # filing_date = date_obj.isoformat(timespec='milliseconds').replace('+00:00', 'Z')

            except ValueError as e:
                print(f"Date parsing error: {e}")
                filing_date = None

        except NoSuchElementException:
            filing_date = None

       # Grant date extraction
        try:
            # Locate the container div containing 'Application granted' or 'Application not granted'
            check_granted = driver.find_element(
                By.XPATH,
                '//div[@class="event layout horizontal style-scope application-timeline"][.//span[text()="Application granted"] or .//span[text()="Application not granted"]]'
            )

            # Get the inner text of the status
            status_text = check_granted.text.lower()

            if "not granted" not in status_text:
                # Grant date is usually the first child div of this container
                grant_date_raw = check_granted.find_element(By.XPATH, './div[1]').text.strip()

                # Normalize long month names if needed (optional)
                grant_date_raw = (grant_date_raw
                                .replace("July", "Jul")
                                .replace("June", "Jun")
                                .replace("September", "Sep")
                                .replace("August", "Aug"))

                # Parse into ISO format
                try:
                    date_obj = datetime.strptime(grant_date_raw, '%Y-%m-%d')
                except ValueError:
                    try:
                        date_obj = datetime.strptime(grant_date_raw, '%d-%b-%Y')
                    except ValueError:
                        grant_date = None
                    else:
                        grant_date = f"{date_obj.strftime('%Y-%m-%d')}T00:00:00.000Z"
                else:
                    grant_date = f"{date_obj.strftime('%Y-%m-%d')}T00:00:00.000Z"
            else:
                grant_date = None

        except NoSuchElementException:
            grant_date = None



        DE_number = ""


        #status
        try:
            status_element = driver.find_element(By.XPATH, '//*[@id="wrapper"]/div[1]/div[2]/section/application-timeline/div/div[9]/div[3]/span')
            status = status_element.text.strip()
        except NoSuchElementException:
            status = ""
         
        application_type = ""

        google_site = driver.current_url


        # Open the second driver for USPTO site
        another_url = "https://fees.uspto.gov/MaintenanceFees/"
        try:
            driver.set_page_load_timeout(15)
            driver.get(another_url)
        except TimeoutException:
            print("Page load took too long, refreshing...")
            driver.execute_script("window.stop();")  # stop loading
            driver.refresh()

        try:
            patent_input_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "patentNumber_0"))
            )
            patent_input_element.clear()
            patent_input_element.send_keys(grant_number)
        except Exception as e:
            print(f"Error entering patent number: {e}")
        # Wait for and input the application number
        try:
            app_input_element = driver.find_element(By.ID, "applicationNumber_0")
            app_input_element.clear()
            app_input_element.send_keys(application_number)
    
        except Exception as e:
            print(f"Error entering application number: {e}")
        
        submit_button = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '/html/body/app-root/div/app-mfs-landing/div/app-by-patent-application/div/div/div/form/div[2]/button'))
                )   
        driver.execute_script("arguments[0].click();", submit_button)

        # Entity extraction
        try:
            entity_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '/html/body/app-root/div/app-mfs-details/div/div[2]/div[1]/div[4]/div/div[2]/div[2]/span'))
                    )            
            entity = entity_element.text.strip()
        
            if entity.lower() == "small":
                entity = "Small"
            elif entity.lower() == "micro":
                entity = "Micro"
            elif entity.lower() == "undiscounted":
                entity = "Large"

        except NoSuchElementException:
            entity = ""
        
        #lawyer extracttion
        try:
            lawyer_element = driver.find_element(By.XPATH, '/html/body/app-root/div/app-mfs-details/div/div[2]/div[1]/div[4]/div/div[4]/div[2]/span')
            lawyer = lawyer_element.text.strip()
            
            lawyer = lawyer_element.text.strip().split('\n')[0]
                
        except NoSuchElementException:
            lawyer = ""

        #Due date extraction
        try:
            table = driver.find_element(By.CLASS_NAME, "adminHistoryTable")
            rows = table.find_elements(By.TAG_NAME, "tr")[1:]  # skip headers

            for row in rows:
                cols = row.find_elements(By.TAG_NAME, "td")
                if len(cols) < 6:
                    continue
                fee_status = cols[5].text.strip().lower()
                if "not due" in fee_status:
                    surcharge_date_str = cols[2].text.strip()  # Surcharge Starts
                    if surcharge_date_str:
                        # Parse the date (format: MM/DD/YYYY)
                        surcharge_date = datetime.strptime(surcharge_date_str, "%m/%d/%Y")
                        calculated_due = surcharge_date - timedelta(days=1)
                        due_date = f"{calculated_due.strftime('%Y-%m-%d')}T00:00:00.000Z"

                        # # Add current UTC time
                        # now = datetime.now(timezone.utc)
                        # calculated_due = calculated_due.replace(
                        #     hour=now.hour, minute=now.minute, second=now.second,
                        #     microsecond=now.microsecond, tzinfo=timezone.utc
                        # )

                        # # Format to ISO 8601 with milliseconds and 'Z'
                        # due_date = calculated_due.isoformat(timespec='milliseconds').replace('+00:00', 'Z')
                        break
            else:
                due_date = None # if no matching row is found

        except NoSuchElementException:
            due_date = None

        # # Extracting the current URL
        PTO_site = driver.current_url 

        # Check if due_date or filing_date or entity is missing
        if grant_date is None or due_date is None or entity == "":
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "wheN_RUN": when_run,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "US",
                "WEB_SCRAPER_STATUS": False
            }       
  

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "US",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }

    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "US",
            "WEB_SCRAPER_STATUS": False
        }