from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime
from datetime import datetime, timezone
import calendar
import time


# Netherland Region
def scrape_NL(driver, application_number, template_id):

    url = "https://mijnoctrooi.rvo.nl/fo-eregister-view/search"
    driver.get(url)

    # region-specific scraping logic for NL
    try:
        # Ensure application number starts with "EP"
        if not application_number.upper().startswith("EP"):
            application_number = "EP" + application_number
        
        input_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.NAME, "number"))
        )
        input_element.clear()
        input_element.send_keys(application_number + Keys.ENTER)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        print(f"Searching for: {application_number}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        # Application Number
        application_no_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="tt"]/div[2]/div[1]/div/dl[2]/dd[1]'))
        )
        raw_app_number = application_no_element.text.strip()

        # Remove "EP" prefix
        application_number = raw_app_number.replace("EP", "").strip()

        #grant
        try:    
            grant_element = driver.find_element(By.XPATH, '//*[@id="tt"]/div[2]/div[1]/div/dl[1]/dd[1]')
            grant_number = grant_element.text.strip()

        except NoSuchElementException:
            grant_number = ""
        
        #title
        try:    
            title_element = driver.find_element(By.XPATH, '//*[@id="Main"]/p/strong[2]')
            title = title_element.text.strip()

        except NoSuchElementException:
            title = ""
        
        entity_size = ""

        #filled by
        try:    
            filled_by_element = driver.find_element(By.XPATH, '//*[@id="tt"]/div[2]/div[1]/div/dl[7]/dd')
            filled_by_text = filled_by_element.text.strip()

        except NoSuchElementException:
            filled_by_text = ""

        # INTERNATIONAL FILING DATE
        try:
            filing_date_element = driver.find_element(By.XPATH, '//*[@id="tt"]/div[2]/div[1]/div/dl[3]/dd[1]')
            filing_date_raw = filing_date_element.text.strip()

            if filing_date_raw:
                try:
                    filing_date_parsed = datetime.strptime(filing_date_raw, "%d/%m/%Y")
                    filing_date = filing_date_parsed.strftime("%Y-%m-%d") + "T00:00:00.000Z"
                except ValueError as e:
                    print(f"Error parsing INTERNATIONAL FILING DATE: '{filing_date_raw}' → {e}")
                    filing_date = None
                    filing_date_parsed = None
            else:
                filing_date = None
                filing_date_parsed = None

        except NoSuchElementException:
            filing_date = None
            filing_date_parsed = None

        # GRANT DATE
        try:
            grant_date_element = driver.find_element(By.XPATH, '//*[@id="tt"]/div[2]/div[1]/div/dl[3]/dd[2]')
            grant_date_raw = grant_date_element.text.strip()

            if grant_date_raw:
                try:
                    grant_date_parsed = datetime.strptime(grant_date_raw, "%d/%m/%Y")
                    grant_date = grant_date_parsed.strftime("%Y-%m-%d") + "T00:00:00.000Z"
                except ValueError as e:
                    print(f"Error parsing GRANT DATE: '{grant_date_raw}' → {e}")
                    grant_date = None
            else:
                grant_date = None

        except NoSuchElementException:
            grant_date = None

        # DUE DATE
        try:
            due_date_element = driver.find_element(By.XPATH, '//dl[@class="Grid LeftCol"]/dt[normalize-space(text())="Annual Fee(s) Due Date:"]/following-sibling::dd[1]')
            due_date_raw = due_date_element.text.strip()

            if due_date_raw:
                try:
                    due_date_parsed = datetime.strptime(due_date_raw, "%d/%m/%Y")
                    due_date = due_date_parsed.strftime("%Y-%m-%d") + "T00:00:00.000Z"
                except ValueError as e:
                    print(f"Error parsing DUE DATE: '{due_date_raw}' → {e}")
                    due_date = None
            else:
                if filing_date_parsed:
                    try:
                        year_plus_4 = filing_date_parsed.year + 4
                        month = filing_date_parsed.month
                        last_day = calendar.monthrange(year_plus_4, month)[1]
                        due_date_parsed = datetime(year_plus_4, month, last_day)
                        due_date = due_date_parsed.strftime("%Y-%m-%d") + "T00:00:00.000Z"
                    except Exception as e:
                        print(f"Error calculating DUE DATE from FILING DATE: {e}")
                        due_date = None
                else:
                    due_date = None

        except NoSuchElementException:
            if filing_date_parsed:
                try:
                    year_plus_4 = filing_date_parsed.year + 4
                    month = filing_date_parsed.month
                    last_day = calendar.monthrange(year_plus_4, month)[1]
                    due_date_parsed = datetime(year_plus_4, month, last_day)
                    due_date = due_date_parsed.strftime("%Y-%m-%d") + "T00:00:00.000Z"
                except Exception as e:
                    print(f"Error calculating DUE DATE from FILING DATE: {e}")
                    due_date = None
            else:
                due_date = None
        

        #lawyer
        lawyer = None  # Default fallback as None

        try:
            # Get all <dl> elements with class containing both 'Grid' and 'RightCol'
            dl_elements = driver.find_elements(By.XPATH, "//dl[contains(@class, 'Grid') and contains(@class, 'RightCol')]")

            for dl in dl_elements:
                dt_elements = dl.find_elements(By.TAG_NAME, "dt")
                dd_elements = dl.find_elements(By.TAG_NAME, "dd")

                # Safely pair <dt> and <dd>
                for dt, dd in zip(dt_elements, dd_elements):
                    dt_text = dt.text.strip().lower().replace(":", "")
                    dd_text = dd.text.strip()

                    if "payer" in dt_text:  # ✅ lowercase match
                        lawyer = dd_text
                        break

                if lawyer is not None:
                    break  # Stop if found

        except Exception as e:
            print("Error during lawyer extraction:", e)
            lawyer = None  # fallback

        print("Lawyer:", lawyer)

        
        DE_number = ""

        #status
        try:
            status_element = driver.find_element(By.XPATH, '//*[@id="tt"]/div[2]/div[1]/div/dl[1]/dd[4]')
            status = status_element.text.strip()
        except NoSuchElementException:
            status = ""
         
        application_type = ""
        google_site = ""

        # Extracting the current URL
        PTO_site = driver.current_url

        # Final Application Number
        application_number = application_number.replace("EP", "").strip()

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "NL",
            "granT_NUMBER": grant_number,
            "title" : title,
            "entity_size": entity_size,
            "fileD_BY": filled_by_text,
            "international_filing_date": filing_date,
            "grant_date": grant_date,
            "due_date": due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "NL",
            "WEB_SCRAPER_STATUS": False
        }