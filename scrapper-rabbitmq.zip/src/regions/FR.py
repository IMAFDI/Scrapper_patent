from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from seleniumbase import Driver
from datetime import datetime
from datetime import datetime, timezone

#Function Defination for France scraping
def scrape_FR(main_driver, application_number, template_id):
    url = "https://data.inpi.fr/recherche_avancee/brevets"
    main_driver.get(url)

    try: 
        input_element = WebDriverWait(main_driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//*[@id='number']"))
        )
        input_element.clear()
        input_element.send_keys(application_number + Keys.ENTER)

        Patent_site = WebDriverWait(main_driver, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/main/div[3]/div/div/div[2]/div[2]/div/div[1]/div/div[2]/div[1]/a')))
        # Patent_site.click()


        url = Patent_site.get_attribute("href")
        driver = Driver(uc =True)
        driver.uc_open_with_reconnect(url, 4)


        print(f"Searching for: {application_number}")
        print("-" * 20)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')


        #Application Number Extraction 
        #International Filling Date Extraction
        application_number=""
        filing_date=None
        try:
            application_number_filing_date_element = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//*[@id='notice-description']/div/div[2]/div[4]/p[2]")))
            application_number_filing_date_list = application_number_filing_date_element.text.strip().split("-")
            application_number= application_number_filing_date_list[0].strip()

            filing_date_raw = application_number_filing_date_list[1].strip()
            if filing_date_raw:
                filing_date = f"{datetime.strptime(filing_date_raw, '%d/%m/%Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
            else:
                filing_date = None

        except NoSuchElementException:
            application_number=""
            filing_date=None


        #title extraction
        try:
            title_element = WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located((By.XPATH, '//*[@id="notice-description"]/div/div[2]/div[1]/p[2]'))
            )
            title = title_element.text.strip()

        except NoSuchElementException:
            title = ""
        
        entity = ""


        #Filled by extraction
        try:
            filled_by_element = WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located((By.XPATH, '//*[@id="notice-description"]/div/div[4]/div[2]/div/p'))
            )
            filled_by_text = filled_by_element.text.split("-")[0].strip()

        except NoSuchElementException:
            filled_by_text = ""
        

        #Grant Number Extraction 
        #Grant Date Extraction
        grant_number=""
        grant_date=None
        try:
            grant_number_grant_date_element = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="notice-description"]/div/div[2]/div[2]/p[2]')))
            grant_number_grant_date_list = grant_number_grant_date_element.text.strip().split("-")
            grant_number= grant_number_grant_date_list[0].strip()

            grant_date_raw = grant_number_grant_date_list[1].strip()
            if grant_date_raw:
                grant_date = f"{datetime.strptime(grant_date_raw, '%d/%m/%Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
            else:
                grant_date = None

        except NoSuchElementException:
            grant_number=""
            grant_date=None

        
        #due date
        try:
            due_date_element = driver.find_element(By.XPATH, '//*[@id="notice-description"]/div/div[4]/div[9]/p[2]')
            due_date_raw = due_date_element.text.strip()

            # Parse the date
            due_date = f"{datetime.strptime(due_date_raw, '%d/%m/%Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
        except NoSuchElementException:
            due_date = None


        #lawyer extracttion
        try:
            lawyer_element = driver.find_element(By.XPATH, '//*[@id="notice-description"]/div/div[4]/div[4]/div/p')
            lawyer = lawyer_element.text.split("-")[0].strip()
        except NoSuchElementException:
            lawyer = ""

        DE_number= ""

        #status extracttion
        try:
            status_element = driver.find_element(By.XPATH, '//*[@id="status"]')
            status = status_element.text.split(":")[1].strip()

        except NoSuchElementException:
            status = ""
        
        application_type= ""
        google_site= ""
        PTO_site = driver.current_url

        try:
            driver.quit()
        except:
            pass

        # Check if due_date or filing_date or entity is missing
        if filing_date is None or due_date is None:
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "wheN_RUN": when_run,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "FR",
                "WEB_SCRAPER_STATUS": False
            }

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "FR",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:

        try:
            driver.quit()
        except:
            pass

        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "FR",
            "WEB_SCRAPER_STATUS": False
        }
