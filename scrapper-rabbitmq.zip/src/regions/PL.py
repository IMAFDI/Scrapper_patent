from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime
from datetime import datetime, timezone
import time


# Poland Region
def scrape_PL(driver, application_number, template_id):
    # Ensure application number starts with "EP"
    if not application_number.upper().startswith("EP"):
        app_no = "EP" + application_number
    
    # Remove decimal part → keep only number before decimal
    application_number_clean = app_no.replace("EP", "").split('.')[0]

    # Rebuild full application number with EP prefix
    app_no = "EP" + application_number_clean

    url = f"https://ewyszukiwarka.pue.uprp.gov.pl/search/pwp-details/{app_no}?lng=pl"
    driver.get(url)

    # region specific logic for PL
    try: 

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        application_number = application_number
        print(f"Searching for: {app_no}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        try:
            wait = WebDriverWait(driver, 10)

            # Click the dropdown to open language options
            dropdown_trigger = wait.until(
                EC.element_to_be_clickable((By.XPATH, "//p-dropdown//div[contains(@class,'ui-dropdown-trigger')]"))
            )
            dropdown_trigger.click()

            # Click on the "EN" option
            en_option = wait.until(
                EC.element_to_be_clickable((By.XPATH, "//li[@role='option']/span[normalize-space()='EN']"))
            )
            en_option.click()

            # Wait for page to reload (wait for some EN-labeled field to appear)
            wait.until(
                EC.presence_of_element_located((By.XPATH, "//td[normalize-space()='English title']"))
            )
            time.sleep(10) 

        except Exception as e:
            print("Error selecting EN:", e)

        #grant number
        try:    
            grant_element = driver.find_element(By.XPATH, '//app-pwp-details-main//table//tr[1]/td[4]//b')
            grant_number = grant_element.text.strip()

        except NoSuchElementException:
            grant_number = ""
        
        #title
        try:    
            title_element = driver.find_element(By.XPATH, "//td[normalize-space()='English title']/following-sibling::td[1]//span")
            title = title_element.text.strip()
            print(title)

        except NoSuchElementException:
            title = ""
        
        # Filed By
        try:
            filed_by_element = driver.find_element(By.XPATH, "//td[normalize-space()='Applicant/Holder']/following-sibling::td[1]//span")
            filled_by_text = filed_by_element.text.strip()
        except NoSuchElementException:
            filled_by_text = ""
        
        def standardize_date(raw_date):
            raw_date = raw_date.strip()
            try:
                # If already in ISO format
                datetime.strptime(raw_date, "%Y-%m-%d")
                return raw_date + "T00:00:00.000Z"
            except ValueError:
                pass

            # Try common non-ISO formats
            for fmt in ("%d.%m.%Y", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d"):
                try:
                    parsed = datetime.strptime(raw_date, fmt)
                    return parsed.strftime("%Y-%m-%dT00:00:00.000Z")
                except ValueError:
                    continue

            return None  # If parsing fails
        
        # International Filing Date
        try:    
            element = driver.find_element(By.XPATH, "//td[normalize-space()='Application date']/following-sibling::td[1]")
            filing_date = standardize_date(element.text)
        except NoSuchElementException:
            filing_date = None

        # Grant Date
        try:    
            element = driver.find_element(By.XPATH, "//td[normalize-space()='Data publikacji o udzieleniu EP (B1)']/following-sibling::td[1]//span")
            grant_date = standardize_date(element.text)
        except NoSuchElementException:
            grant_date = None

        # Due Date
        try:    
            element = driver.find_element(By.XPATH, "//td[normalize-space()='Date of payment for the next protection period']/following-sibling::td[1]")
            due_date = standardize_date(element.text)
        except NoSuchElementException:
            due_date = None


        #lawyer
        try:    
            lawyer_element = driver.find_element(By.XPATH, "//td[normalize-space()='Pełnomocnik Zgłaszającego/Uprawnionego, Typ Pełnomocnictwa']/following-sibling::td[1]//span")
            lawyer = lawyer_element.text.strip()

        except NoSuchElementException:
            lawyer = ""
        

        DE_number = ""

        #Status
        try:    
            status_element = driver.find_element(By.XPATH, "//td[normalize-space()='Status']/following-sibling::td[1]//span")
            status = status_element.text.strip()

        except NoSuchElementException:
            status = ""
        
        entity = "" 
        application_type = ""
        google_site = ""

        # Extracting the current URL
        PTO_site = driver.current_url

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "PL",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "PL",
            "WEB_SCRAPER_STATUS": False
        }