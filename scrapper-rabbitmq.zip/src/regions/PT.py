from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from seleniumbase import Driver
from datetime import datetime
from datetime import datetime, timezone
import time
from bs4 import BeautifulSoup

# Portugal Region
def scrape_PT(application_number, template_id):

    # Ensure application number starts with "EP"
    if not application_number.upper().startswith("EP"):
        app_no = "EP" + application_number
    
    # Remove decimal part → keep only number before decimal
    application_number_clean = app_no.replace("EP", "").split('.')[0]

    # Rebuild full application number with EP prefix
    app_no = "EP" + application_number_clean

    driver = Driver(uc =True)
    url = f"https://register.epo.org/application?number={app_no}"
    print(url)
    driver.uc_open_with_reconnect(url, 4)

    # region specific logic for PT
    try: 
        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        application_number = application_number
        print(f"Searching for: {application_number}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        # Click on Legal Status
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "epoContentNav"))
        )

        # Find and click the "EP Legal status" link
        legal_status_link = driver.find_element(By.XPATH, "//a[contains(text(),'EP Legal status')]")
        print("🔗 Clicking on: EP Legal status")
        legal_status_link.click()

        # Wait 5 seconds on the new page
        print("⏳ Waiting 5 seconds on Legal status page...")
        time.sleep(5)

        # Now click on PT Link
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "ext"))
        )

        # Find the <a> tag with text "PT" and click it
        tr_link = driver.find_element(By.XPATH, "//a[@class='ext' and text()='PT']")
        tr_url = tr_link.get_attribute("href")
        print(f"🔗 Found PT link: {tr_url}")

        # Navigate to the Portugal patent register link
        driver.get(tr_url)

        # Wait on that page for 5 seconds
        print("⏳ Waiting 5 seconds on Portugal site...")
        time.sleep(5)

        # Function to convert DD/MM/YYYY → YYYY-MM-DDT00:00:00.000Z
        def convert_to_iso(date_str):
            try:
                dt = datetime.strptime(date_str, "%d-%m-%Y")
                return dt.strftime("%Y-%m-%dT00:00:00.000Z")
            except:
                return ""

        soup = BeautifulSoup(driver.page_source, "html.parser")

        # Extract Grant Number
        try:
            grant_header = soup.find("span", id="ext-gen66")
            grant_text = grant_header.get_text(strip=True)
            if "Nr." in grant_text:
                grant_number_raw = grant_text.split("Nr.")[1].strip()
                grant_number = f"EP{grant_number_raw}"
            else:
                grant_number = ""
        except Exception:
            grant_number = ""

        print("grant_number:", grant_number)

        # Filing Date
        try:
            filing_date_raw = soup.find('b', string='Filing Date').find_next('td').get_text(strip=True)
            filing_date = convert_to_iso(filing_date_raw)
            print("Filing Date :", filing_date)
        except Exception:
            filing_date = None

        # Grant Date (from Final Decision Date)
        try:
            grant_date_raw = soup.find('b', string='Final Decision Date').find_next('td').get_text(strip=True)
            grant_date = convert_to_iso(grant_date_raw)
            print("Grant Date :", grant_date)
        except Exception:
            grant_date = None
        
        # Due Date
        # Maintenance Fees: Paid → number of years
        try:
            paid_td = soup.find('td', string='Paid')
            paid_years = int(paid_td.find_next_sibling('td').get_text(strip=True))
            # print("Paid Years:", paid_years)
        except Exception:
            paid_years = 0
            # print("Paid Years: Not found or invalid")

        # Due Date: Filing Date + Paid Years
        try:
            if filing_date and paid_years:
                filing_date_dt = datetime.strptime(filing_date, "%Y-%m-%dT00:00:00.000Z")
                due_date_dt = filing_date_dt.replace(year=filing_date_dt.year + paid_years)
                due_date = due_date_dt.strftime("%Y-%m-%dT00:00:00.000Z")
                print("Due Date:", due_date)
            else:
                due_date = ""
        except Exception as e:
            print(f"Error calculating due date: {e}")
            due_date = ""

        # Title
        try:
            title = soup.find('div', style=lambda x: x and "text-align: left" in x).get_text(strip=True)
        except Exception:
            title = ""

        # Applicants/Owners
        try:
            filled_by_text = soup.find('b', string='Applicants/Owners').find_next('td').get_text(strip=True)
        except Exception:
            filled_by_text = ""

        # Lawyer (Representative)
        try:
            rep_lines = soup.find_all('td', style=lambda x: x and 'text-align: left' in x)
            representative_index = [i for i, td in enumerate(rep_lines) if 'JOÃO' in td.text or 'Representative' in td.text]
            lawyer = ' '.join([rep_lines[i].get_text(strip=True) for i in representative_index[:3]])
        except Exception:
            lawyer = ""

        # Legal Status
        try:
            status = soup.find('b', string='Legal Status').find_next('td').get_text(strip=True)
        except Exception:
            status = ""

        entity = ""
        DE_number = ""
        application_type = ""
        google_site = ""
        

        # Extracting the current URL
        PTO_site = driver.current_url

        # ✅ Close the driver once scraping is done
        driver.quit()

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "PT",
            "granT_NUMBER": grant_number,
            "title" : title,
            "entity_size": entity,
            "fileD_BY": filled_by_text,
            "international_filing_date": filing_date,
            "grant_date": grant_date,
            "due_date": due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        try:
            driver.quit()  # Make sure driver still closes on error
        except:
            pass
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "PT",
            "WEB_SCRAPER_STATUS": False
        }