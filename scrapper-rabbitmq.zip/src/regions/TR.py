from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from dateutil.relativedelta import relativedelta
from seleniumbase import Driver
from datetime import datetime
from datetime import datetime, timezone
import time
from bs4 import BeautifulSoup


# TR Region
def scrape_TR(application_number, template_id):

    # Ensure application number starts with "EP"
    if not application_number.upper().startswith("EP"):
        app_no = "EP" + application_number
    
    # Remove decimal part → keep only number before decimal
    application_number_clean = app_no.replace("EP", "").split('.')[0]

    # Rebuild full application number with EP prefix
    app_no = "EP" + application_number_clean

    driver = Driver(uc =True)
    url = f"https://register.epo.org/application?number={app_no}"
    print(url)
    driver.uc_open_with_reconnect(url, 4)

    # region specific logic for TR
    try: 

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        application_number = application_number
        print(f"Searching for: {application_number}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        # Click on Legal Status
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "epoContentNav"))
        )

        # Find and click the "EP Legal status" link
        legal_status_link = driver.find_element(By.XPATH, "//a[contains(text(),'EP Legal status')]")
        print("🔗 Clicking on: EP Legal status")
        legal_status_link.click()

        # Wait 5 seconds on the new page
        print("⏳ Waiting 5 seconds on Legal status page...")
        time.sleep(5)

        # Now click on TR Link
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "ext"))
        )

        # Find the <a> tag with text "TR" and click it
        tr_link = driver.find_element(By.XPATH, "//a[@class='ext' and text()='TR']")
        tr_url = tr_link.get_attribute("href")
        print(f"🔗 Found TR link: {tr_url}")

        # Navigate to the Turkish patent register link
        driver.get(tr_url)

        # Wait on that page for 5 seconds
        print("⏳ Waiting 5 seconds on Turkish site...")
        time.sleep(5)

        # Grant Number
        soup = BeautifulSoup(driver.page_source, "html.parser")

        def extract_label(field_name):
            spans = soup.find_all("span")
            for span in spans:
                if span.text.strip().startswith(field_name):
                    label_tag = span.find_next("label")
                    if label_tag:
                        return label_tag.text.strip()
            return ""

        # Extract desired fields
        grant_number = extract_label("European Patent Publication Number (B1) : ")
        print(grant_number)
        

        # Title
        title_row = soup.select("table.table-bordered tr")
        for row in title_row:
            cells = row.find_all("td")
            if len(cells) >= 2 and "Name Of Invention" in cells[0].text.strip():
                title = cells[1].text.strip()
                break
            else:
                "Not Found"

        
        # Filed By
        filled_by_text = ""

        tables = soup.select("div.portlet.light.bordered")
        for table in tables:
            filed_by_raw = table.select_one("span.caption-subject")
            if filed_by_raw and "Applicants" in filed_by_raw.text.strip():
                rows = table.select("table.table-bordered tbody tr")
                for row in rows:
                    cells = row.find_all("td")
                    if len(cells) >= 2:
                        filled_by_text = cells[1].text.strip()
                        break

        print("✅ Applicant Name:", filled_by_text)

        # Function to extract label text by key
        def get_label_value(soup, label_text):
            spans_tag = soup.find_all("span")
            for span in spans_tag:
                if label_text in span.get_text(strip=True):
                    label = span.find_next("label")
                    if label:
                        return label.get_text(strip=True)
            return None

        # International Filing Date
        try:
            raw_app_date = get_label_value(soup, "Application Date")
            filing_date = datetime.strptime(raw_app_date, "%d-%m-%Y").strftime("%Y-%m-%dT00:00:00.000Z") if raw_app_date else None
        except:
            filing_date = None

        # Grant Date
        try:
            raw_grant_date = get_label_value(soup, "Grant Date")
            grant_date = datetime.strptime(raw_grant_date, "%d-%m-%Y").strftime("%Y-%m-%dT00:00:00.000Z") if raw_grant_date else None
        except:
            grant_date = None

        # Due Date
        try:
            due_date_row = soup.select("table.table-bordered tbody tr")
            last_due_date_row = due_date_row[-1]  # Last row
            year_number = int(last_due_date_row.find_all("td")[0].text.strip())  # e.g. 8

            if filing_date:
                filing_date_clean = filing_date.split("T")[0]  # Extract 'YYYY-MM-DD'
                intl_filing_date_dt = datetime.strptime(filing_date_clean, "%Y-%m-%d")
                due_date_raw = intl_filing_date_dt + relativedelta(years=year_number)
                due_date = due_date_raw.strftime("%Y-%m-%dT00:00:00.000Z")
            else:
                due_date = None

        except Exception:
            due_date = None
        

        # Lawyer
        try:
            # Find all portlet blocks
            portlet_blocks = driver.find_elements(By.XPATH, "//div[contains(@class, 'portlet light bordered')]")

            lawyer = ""
            for block in portlet_blocks:
                try:
                    # Look for the title span inside the current block
                    title_span = block.find_element(By.XPATH, ".//span[contains(@class,'caption-subject')]")
                    if "Attorney Information" in title_span.text.strip():
                        # This is the correct section; now look for the second <span> inside the Name <td>
                        name_cell = block.find_element(By.XPATH, ".//tr[1]/td[2]")
                        spans = name_cell.find_elements(By.TAG_NAME, "span")

                        for span in spans:
                            text = span.text.strip()
                            if text and not text.lower().startswith("merve"):  # filter if needed
                                lawyer = text
                        break  # break once we've found and extracted it
                except:
                    continue

            print("Lawyer:", lawyer)

        except Exception as e:
            lawyer = ""



        entity = ""
        status = "" 
        DE_number = ""
        application_type = ""
        google_site = ""

        # Extracting the current URL
        PTO_site = driver.current_url

        # ✅ Close the driver once scraping is done
        driver.quit()

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "TR",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        try:
            driver.quit()  # Make sure driver still closes on error
        except:
            pass
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "TR",
            "WEB_SCRAPER_STATUS": False
        }
