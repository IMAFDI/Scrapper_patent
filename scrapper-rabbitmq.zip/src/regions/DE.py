from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime
from datetime import datetime, timezone

#Function Defination for Germany scraping
def scrape_DE(driver, application_number, template_id):
    url = "https://register.dpma.de/DPMAregister/pat/basis"
    driver.get(url)

    # region-specific scraping logic for DE
    try:
        input_element = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//*[@id='akzPn']"))
        )

        input_element.clear()
        input_element.send_keys(application_number + Keys.ENTER)
        
        PTO_site = driver.current_url
        

        print(f"Searching for: {application_number}")
        print("-" * 20)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')


        #extraction
        grant_number = ""
        title = ""
        filled_by_text = ""
        filing_date = None
        grant_date = None
        due_date = None
        status = ""
        

        try:
            table = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "stammdaten_tabelle")))

            # Now get all the rows inside the table
            rows = table.find_elements(By.XPATH, ".//tbody/tr")
            for row in rows:
                try:
                    feld = row.find_element(By.XPATH, ".//td[@data-th='Feld']").text.strip()
                    if "EAKZ" in feld and application_number == "":
                        inhalt = row.find_element(By.XPATH, ".//td[@data-th='Inhalt']").text.strip()
                        application_number = inhalt.replace(" ","")
                    if "DAKZ" in feld and grant_number == "":
                        inhalt = row.find_element(By.XPATH, ".//td[@data-th='Inhalt']").text.strip()
                        grant_number = inhalt.replace(" ","")
                    if "INH" in feld and filled_by_text == "":
                        inhalt = row.find_element(By.XPATH, ".//td[@data-th='Inhalt']").text.strip()
                        filled_by_text = inhalt.strip()
                    if "WAT" in feld and filing_date == None:
                        inhalt = row.find_element(By.XPATH, ".//td[@data-th='Inhalt']").text.strip()
                        filing_date = f"{datetime.strptime(inhalt.strip(), '%d.%m.%Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
                    if "PET" in feld and grant_date == None:
                        inhalt = row.find_element(By.XPATH, ".//td[@data-th='Inhalt']").text.strip()
                        grant_date = f"{datetime.strptime(inhalt.strip(), '%d.%m.%Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
                    if "FT" in feld and due_date == None:
                        inhalt_element = row.find_element(By.XPATH, ".//td[@data-th='Inhalt']")
                        inhalt_text = inhalt_element.get_attribute("innerText").strip()
                        first_line = inhalt_text.split("\n")[0].strip()  # get the date line
                        due_date = f"{datetime.strptime(first_line, '%d.%m.%Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
                    if "TI" in feld and title == "":
                        inhalt = row.find_element(By.XPATH, ".//td[@data-th='Inhalt']").text.strip()
                        title = inhalt.strip()
                        if '\\u' in title:
                            break
                    if "ST" in feld and status == "":
                        inhalt = row.find_element(By.XPATH, ".//td[@data-th='Inhalt']").text.strip()
                        status = inhalt.strip()
                        if '\\u' in status:
                            break

                except:
                    continue
                
                    
        except NoSuchElementException:
            print("Table not found")

        entity = ""
        DE_number = grant_number
        lawyer = ""
        application_type = ""
        google_site =""

        # Check if due_date or filing_date or entity is missing
        if filing_date is None or due_date is None:
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "wheN_RUN": when_run,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "DE",
                "WEB_SCRAPER_STATUS": False
            }

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "DE",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "DE",
            "WEB_SCRAPER_STATUS": False
        }