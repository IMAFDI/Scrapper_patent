from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from seleniumbase import Driver
from datetime import datetime
from datetime import datetime, timezone
import time
from bs4 import BeautifulSoup


# Iceland Region
def scrape_IS(application_number, template_id):

    # Normalize application number to EP######## format
    application_number_clean = application_number.upper().replace("EP", "").replace("E", "").split('.')[0]
    app_no = "EP" + application_number_clean


    driver = Driver(uc =True)
    url = f"https://register.epo.org/application?number={app_no}"
    print(url)
    driver.uc_open_with_reconnect(url, 4)

    # region specific logic for IS
    try: 
        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        print(f"Searching for: {app_no}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        # Click on Legal Status
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "epoContentNav"))
        )

        # Find and click the "EP Legal status" link
        legal_status_link = driver.find_element(By.XPATH, "//a[contains(text(),'EP Legal status')]")
        print("🔗 Clicking on: EP Legal status")
        legal_status_link.click()

        # Wait 5 seconds on the new page
        print("⏳ Waiting 5 seconds on Legal status page...")
        time.sleep(5)

        # Now click on IS Link
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "ext"))
        )

        # Find the <a> tag with text "IS" and click it
        tr_link = driver.find_element(By.XPATH, "//a[@class='ext' and text()='IS']")
        tr_url = tr_link.get_attribute("href")
        print(f"🔗 Found IS link: {tr_url}")

        # Navigate to the Iceland patent register link
        driver.get(tr_url)

        # Wait on that page for 5 seconds
        print("⏳ Waiting 5 seconds on Iceland site...")
        time.sleep(5)

        
        def format_date(date_str):
            """Convert 'dd.mm.yyyy' or 'd.m.yyyy' to 'yyyy-mm-ddT00:00:00.000Z'"""
            try:
                return datetime.strptime(date_str.strip(), "%d.%m.%Y").strftime("%Y-%m-%dT00:00:00.000Z")
            except:
                return ""

        soup = BeautifulSoup(driver.page_source, "html.parser")  # use your HTML string or driver.page_source

        # Grant number from <h1>
        grant_number = soup.find('h1').get_text(strip=True)

        # Title from class under id="patent"
        title_tag = soup.select_one('#patent h3.Patent_patentTitle__k8xOS')
        title = title_tag.get_text(strip=True) if title_tag else ""

        # Status
        status_tag = soup.find('h5', string="Status: ")
        status = status_tag.find_next('span').text.strip() if status_tag else ""

        # EP appl. date
        filing_date = None
        filing_tag = soup.find('h5', string="EP appl. date: ")
        filing_date = format_date(filing_tag.find_next('span').text) if filing_tag else ""

        # EP published date
        grant_date = None
        grant_tag = soup.find('h5', string="EP published: ")
        grant_date = format_date(grant_tag.find_next('span').text) if grant_tag else ""

        # EP application number
        app_no_tag = soup.find('h5', string="EP application number: ")
        application_number = app_no_tag.find_next('span').text.strip() if app_no_tag else ""

        # Next due date
        due_date = None
        due_date_tag = soup.find('h5', string="Next due date: ")
        due_date = format_date(due_date_tag.find_next('span').text) if due_date_tag else None

        # Owner name
        owner_tag = soup.select_one('#owner li span')
        filled_by_text = owner_tag.text.strip() if owner_tag else ""

        # Agent name
        agent_tag = soup.select_one('#agent li span')
        lawyer = agent_tag.text.strip() if agent_tag else ""

        entity = ""
        DE_number = ""
        application_type = ""
        google_site = ""
        

        # Extracting the current URL
        PTO_site = driver.current_url

        # ✅ Close the driver once scraping is done
        driver.quit()

        # Check if due_date or filing_date or entity is missing
        if filing_date is None or due_date is None:
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "wheN_RUN": when_run,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "IS",
                "WEB_SCRAPER_STATUS": False
            }  

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "HU",
            "granT_NUMBER": grant_number,
            "title" : title,
            "entity_size": entity,
            "fileD_BY": filled_by_text,
            "international_filing_date": filing_date,
            "grant_date": grant_date,
            "due_date": due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        try:
            driver.quit()  # Make sure driver still closes on error
        except:
            pass
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "IS",
            "WEB_SCRAPER_STATUS": False
        }