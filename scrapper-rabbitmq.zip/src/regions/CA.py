from datetime import datetime
from datetime import datetime, timedelta, timezone
import re
import requests # 
from bs4 import BeautifulSoup

#Function Defination for Canada scraping
def scrape_CA(application_number, template_id):

    url = f"https://brevets-patents.ic.gc.ca/opic-cipo/cpd/eng/patent/{application_number}/summary.html?query={application_number}&type=basic_search"
    try:
        print(f"Searching for: {application_number}")
        print("-" * 20)

        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for HTTP errors
        soup = BeautifulSoup(response.text, 'html.parser')

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')

        #Grant number, title extraction
        grant_number = ""
        title = ""
        status = ""

        try:
            table = soup.find('table', id='patentSummaryTable')
            rows = table.find_all('tr')

            for row in rows:
                th = row.find('th')
                td = row.find('td')

                if not th or not td:
                    continue

                th_text = th.get_text(strip=True)

                # Match based on "Patent Application" (grant number row)
                if 'Patent Application' in th_text:
                    # Extract actual number from td
                    grant_number = td.get_text(strip=True)
                    # Remove (11) if present
                    grant_number = re.sub(r'\(11\)\s*', '', grant_number).strip()

                elif 'English Title' in th_text:
                    title = td.get_text(strip=True)
                
                elif 'Status' in th_text:
                    status = td.get_text(strip=True)

        except Exception as e:
            print("Error occurred:", e)


        # Entity extraction
        entity = ""
        try:
            table = soup.find('table', id='paymentHistoryTable')
            rows = table.find_all('tr')
            for row in rows:
                cells = row.find_all('td')
                if cells:
                    fee_type = cells[0].get_text(strip=True).lower()
                    
                    if "basic national fee" in fee_type:
                        # Determine entity size from the fee description
                        if "small" in fee_type:
                            entity = "Small"
                        elif "standard" in fee_type:
                            entity = "Large"
                        else:
                            entity = ""
                        break  # Stop after finding the first match

        except Exception as e:
            print("Error occurred:", e)


        # Filled by, filing date, Lawyer and grant date extraction
        filled_by_text = ""
        filing_date = None
        grant_date = None
        lawyer = ""
        try:
            rows = soup.select('#patentDetailsTable tr')
            for row in rows:
                th = row.find('th')
                td = row.find('td')

                if not th or not td:
                    continue

                th_text = th.get_text(strip=True)

                # Find First Applicant
                try:
                    if "Applicants" in th_text and not filled_by_text:
                        first_li = td.find('li')
                        if first_li:
                            filled_by_text = first_li.get_text(strip=True).split('(')[0].strip()
                except Exception as e:
                    filled_by_text = ""

                # Find PCT Filing Date
                try:
                    if "PCT Filing Date" in th_text or "Filed Date" in th_text and not filing_date:
                        strong_tag = td.find('strong')
                        if strong_tag:
                            filing_date_raw = strong_tag.get_text(strip=True)
                            try:
                                try:
                                    filing_date = f"{datetime.strptime(filing_date_raw, '%d %b %Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
                                except ValueError:
                                    filing_date = f"{datetime.strptime(filing_date_raw, '%Y-%m-%d').strftime('%Y-%m-%d')}T00:00:00.000Z"
                            except ValueError as e:
                                print("Date parsing error:", e)
                                filing_date = None
                except Exception as e:
                    filing_date = None

                # Find Grant Date
                try:
                    if "Issued" in th_text and not grant_date:
                        strong_tag = td.find('strong')
                        if strong_tag and strong_tag.get_text(strip=True):
                            grant_date_raw = strong_tag.get_text(strip=True)
                            try:
                                try:
                                    grant_date = f"{datetime.strptime(grant_date_raw, '%d %b %Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
                                except ValueError:
                                    grant_date = f"{datetime.strptime(grant_date_raw, '%Y-%m-%d').strftime('%Y-%m-%d')}T00:00:00.000Z"
                            except ValueError as e:
                                print("Date parsing error:", e)
                                grant_date = None
                except Exception as e:
                    grant_date = None
                    print("Error extracting grant date:", e)

            
                # Find Lawyer (Agent)
                try:
                    if "Agent" in th_text and not lawyer:
                        strong_tag = td.find('strong')
                        if strong_tag:
                            lawyer = strong_tag.get_text(strip=True)
                            if ',' in lawyer:
                                parts = lawyer.split(',')
                                lawyer = f"{parts[1].strip()} {parts[0].strip()}"
                except Exception as e:
                    lawyer = ""
                    
        except Exception as e:
            print("Error during extraction:", e)
        
        # Due date
        due_date = None
        payment_rows = soup.select('#paymentHistoryTable tbody tr')

        for row in reversed(payment_rows):
            due_date_element = row.select_one('td:nth-of-type(3)')
            if due_date_element:
                raw_text = due_date_element.get_text(strip=True)
                try:
                    # Parse original due date
                    base_date_obj = datetime.strptime(raw_text, "%Y-%m-%d")

                    # Add 1 year and 1 day
                    try:
                        due_date_obj = base_date_obj.replace(year=base_date_obj.year + 1) + timedelta(days=1)
                    except ValueError:
                        # Handle February 29 on non-leap years
                        due_date_obj = base_date_obj + timedelta(days=366)

                    # Format to 'YYYY-MM-DD'
                    due_date = f"{due_date_obj.strftime('%Y-%m-%d')}T00:00:00.000Z"
                    break

                except ValueError:
                    due_date = None
        

        DE_number = ""

        # Status extraction
        status_element = soup.select_one('#patentSummaryTable tbody tr:nth-of-type(4) td')
        status = status_element.get_text(strip=True) if status_element else ""

        application_type = ""
        google_site = ""

        # Check if due_date or filing_date or entity is missing
        if filing_date is None or due_date is None or entity == "":
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "wheN_RUN": when_run,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "CA",
                "WEB_SCRAPER_STATUS": False
            }       


        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "CA",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": url,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "CA",
            "WEB_SCRAPER_STATUS": False
        }