from .AT import scrape_AT
from .AU import scrape_AU
from .BE import scrape_BE
from .BR import scrape_BR
from .CA import scrape_CA
from .CH import scrape_CH
from .CN import scrape_CN
from .DE import scrape_DE
from .DK import scrape_DK
from .EP import scrape_EP
from .ES import scrape_ES
from .FI import scrape_FI
from .FR import scrape_FR
from .GB import scrape_GB
from .GR import scrape_GR
from .HU import scrape_HU
from .IE import scrape_IE
from .JP import scrape_JP
from .KR import scrape_KR
from .NL import scrape_NL
from .NZ import scrape_NZ
from .PL import scrape_PL
from .PT import scrape_PT
from .SE import scrape_SE
from .TR import scrape_TR
from .US import scrape_US

REGION_SCRAPERS = {
    "AT": scrape_AT,
    "AU": scrape_AU,
    "BE": scrape_BE,
    "BR": scrape_BR,
    "CA": scrape_CA,
    "CH": scrape_CH,
    "CN": scrape_CN,
    "DE": scrape_DE,
    "DK": scrape_DK,
    "EP": scrape_EP,
    "ES": scrape_ES,
    "FI": scrape_FI,
    "FR": scrape_FR,
    "GB": scrape_GB,
    "GR": scrape_GR,
    "HU": scrape_HU,
    "IE": scrape_IE,
    "JP": scrape_JP,
    "KR": scrape_KR,  
    "NL": scrape_NL,
    "NZ": scrape_NZ,
    "PL": scrape_PL,
    "PT": scrape_PT,
    "SE": scrape_SE,
    "TR": scrape_TR,
    "US": scrape_US
}

def get_scraper(region_code):
    return REGION_SCRAPERS.get(region_code.upper())
