from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime
from datetime import datetime, timezone

#Function Defination for Great Britain scraping
def scrape_GB(driver, application_number, template_id):
    url = "https://www.search-for-intellectual-property.service.gov.uk/"
    driver.get(url)

    # region-specific scraping logic for GB
    try:
        patent_element = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//*[@id='dynamic-control-radios-fieldset']/div[1]/label"))
        )
        patent_element.click()

        # num_str = str(application_number).strip()
        # if not (num_str.startswith("EP") or num_str.startswith("GB")):
        #     application_number = "EP" + num_str

        
        input_element = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//*[@id='applicationPublicationNumber']"))
        )

        input_element.clear()
        input_element.send_keys(application_number + Keys.ENTER)

        print(f"Searching for: {application_number}")
        print("-" * 20)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        application_number = application_number

        #grant_number extraction
        try:
            grant_number_element = WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located((By.XPATH, '//*[@id="resultsContainer"]/div/div/div/a'))
            )
            grant_number = grant_number_element.text.strip()
            grant_number_element.click()
        except NoSuchElementException:
            grant_number = ""
        
        #title extraction
        try:
            title_element = WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located((By.XPATH, '//*[@id="patentDetailsApplicationTitle"]/dd/div/p'))
            )
            title = title_element.text.strip()
        except NoSuchElementException:
            title = ""

        entity = ""

        # filled by
        try:
            filled_by_element = driver.find_element(By.XPATH, '//*[@id="patentApplicantsOwnersTable"]/tbody/tr/td[1]')
            filled_by_text = filled_by_element.text.strip()
        except NoSuchElementException:
            filled_by_text = ""
        
        #international filing date
        filing_date = None
        try:
            # Find all rows in the summary list
            rows = driver.find_elements(By.CSS_SELECTOR, "#patentDates .govuk-summary-list__row")
            for row in rows:
                try:
                    label = row.find_element(By.CSS_SELECTOR, ".govuk-summary-list__key").text.strip().lower()
                    if "filing date" in label:
                        filing_date_raw = row.find_element(By.CSS_SELECTOR, ".govuk-summary-list__value").text.strip()
                        filing_date = f"{datetime.strptime(filing_date_raw, '%d %B %Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
                        break
                except:
                    continue  # Skip any row with missing elements

        except NoSuchElementException:
            filing_date = None

        #grant date extraction
        grant_date = None
        try:
            # Find all rows in the summary list
            rows = driver.find_elements(By.CSS_SELECTOR, "#patentDates .govuk-summary-list__row")
            for row in rows:
                try:
                    label = row.find_element(By.CSS_SELECTOR, ".govuk-summary-list__key").text.strip().lower()
                    if "publication date" in label:
                        grant_date_raw = row.find_element(By.CSS_SELECTOR, ".govuk-summary-list__value").text.strip()
                        grant_date = f"{datetime.strptime(grant_date_raw, '%d %B %Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
                        break
                except:
                    continue  # Skip any row with missing elements

        except NoSuchElementException:
            grant_date = None
        
        #due date extraction
        due_date = None
        try:
            # Find all rows in the summary list
            rows = driver.find_elements(By.CSS_SELECTOR, "#patentDates .govuk-summary-list__row")
            for row in rows:
                try:
                    label = row.find_element(By.CSS_SELECTOR, ".govuk-summary-list__key").text.strip().lower()
                    if "next renewal date" in label:
                        due_date_raw = row.find_element(By.CSS_SELECTOR, ".govuk-summary-list__value").text.strip()
                        due_date = f"{datetime.strptime(due_date_raw, '%d %B %Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
                        break
                except:
                    continue  # Skip any row with missing elements
                
        except NoSuchElementException:
            due_date = None
        
        #lawyer extracttion
        try:
            lawyer_element = driver.find_element(By.XPATH, '//*[@id="patentRepresentationTable"]/tbody/tr/td[1]')
            lawyer = lawyer_element.text.strip()
        except NoSuchElementException:
            lawyer = ""

        DE_number = ""

        #status extraction
        try:
            status_element = driver.find_element(By.XPATH, '//*[@id="patentDetailsStatus"]/dd/div/p')
            status = status_element.text.strip()
        except NoSuchElementException:
            status = ""
        
        application_type = ""
        google_site =  ""
        PTO_site = driver.current_url

        # Check if due_date or filing_date or entity is missing
        if filing_date is None or due_date is None:
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "GB",
                "WEB_SCRAPER_STATUS": False
            }  

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "GB",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "GB",
            "WEB_SCRAPER_STATUS": False
        }