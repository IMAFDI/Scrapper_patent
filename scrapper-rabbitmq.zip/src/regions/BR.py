from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from dateutil.relativedelta import relativedelta
from datetime import datetime
from datetime import datetime, timezone

#Function Defination for Brazil scraping
def scrape_BR(driver, application_number, template_id):

    url = "https://busca.inpi.gov.br/pePI/servlet/LoginController?action=login"
    driver.get(url)

    try: 
        patente_element = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//*[@id='Map3']/area[5]"))
        )
        patente_element.click()


        input_element = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//*[@id='principal']/table/tbody/tr[6]/td[2]/font/input"))
        )

        input_element.clear()
        input_element.send_keys(application_number + Keys.ENTER)

        application_number_element = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//*[@id='tituloContext']/tr/td[1]/font/a"))
        )
        application_number_element.click()

        print(f"Searching for: {application_number}")
        print("-" * 20)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')

        application_number = application_number

        
        grant_number = ""

    

        #title extraction
        try:
            title_element = WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located((By.XPATH, '//*[@id="tituloContext"]/font'))
            )
            title = title_element.text.strip()

        except NoSuchElementException:
            title = ""
        
        #filled by Extraction
        rows = driver.find_elements(By.XPATH, '//table//tr')

        for row in rows:
            try:
                label = row.find_element(By.XPATH, './td[1]').text.strip()
                if "Nome do Depositante" in label:
                    filled_by_text = row.find_element(By.XPATH, './td[2]').text.strip()
                    break  # Stop once found
                else:
                    filled_by_text = ""
            except NoSuchElementException:
                filled_by_text = ""



        
        #International Filing Date Extraction
        filing_date = None
        for row in rows:
            try:
                label = row.find_element(By.XPATH, './td[1]').text.strip()
                if "Data do Depósito" in label:
                    filing_date_raw = row.find_element(By.XPATH, './td[2]').text.strip()
                    filing_date = f"{datetime.strptime(filing_date_raw, '%d/%m/%Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
                    break
                else:
                    filing_date = None
            except NoSuchElementException:
                filing_date = None


        #grant date extraction
        grant_date_raw = None
        rows = driver.find_elements(By.XPATH, '//table//tr')

        for row in rows:
            try:
                label = row.find_element(By.XPATH, './td[1]').text.strip()
                if "Data da Concessão" in label:
                    grant_date_raw = row.find_element(By.XPATH, './td[2]').text.strip()
                    break
            except NoSuchElementException:
                continue
        # Now process the raw date
        grant_date = None
        if grant_date_raw and grant_date_raw != "-":
            try:
                grant_date = f"{datetime.strptime(grant_date_raw, '%d/%m/%Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
            except:
                grant_date = None


            
            
        #entity extraction
        if grant_date:
            entity = "Granted" if "T00:00:00.000Z" in grant_date else "NotGranted"
        else:
            entity = "NotGranted"



        #lawyer Extraction
        lawyer =""
        for row in rows:
            try:
                label = row.find_element(By.XPATH, './td[1]').text.strip()
                if "Nome do Procurador" in label:
                    lawyer = row.find_element(By.XPATH, './td[2]').text.strip()
                    break
                else:
                    lawyer = ""
            except NoSuchElementException:
                lawyer = ""


        DE_number = ""
        status = ""
        application_type = ""
        google_site =""

        PTO_site = driver.current_url

        #Due Date Extraction
        due_date = None

        try:
            # 1. Find the annuity table
            anuidade_table = driver.find_element(By.XPATH, "//div[@class='accordion-content']//table")


            # 2. Find all header cells
            header_cells = anuidade_table.find_elements(By.XPATH, ".//th")
            unpaid_index = None

            for idx, th in enumerate(header_cells):
                try:
                    img = th.find_element(By.XPATH, ".//img[contains(@src, 'registro_nao_ok.gif')]")
                    unpaid_index = idx + 1  # 1-based indexing for XPath
                    break
                except NoSuchElementException:
                    continue

            if img:

                # 3. Find the "Ordinário" row
                ordinary_row = anuidade_table.find_element(By.XPATH, ".//tr[td/font[contains(text(), 'Ordinário')]]")

                # 4. Get the <td> in the unpaid annuity column
                td = ordinary_row.find_element(By.XPATH, f"./td[{unpaid_index}]")

                # 5. Try to extract the text inside <font>, fallback to <td>
                try:
                    due_date_raw = td.find_element(By.XPATH, "./table/tbody/tr/td[2]/font").text.strip()
                except NoSuchElementException:
                    due_date_raw = td.text.strip()

                # 6. Parse and format the due date safely
                try:
                    parsed_date = datetime.strptime(due_date_raw, '%d/%m/%Y')
                    due_date = f"{parsed_date.strftime('%Y-%m-%d')}T00:00:00.000Z"
                except ValueError as ve:
                    print("⚠️ Error parsing date:", ve)
            else:
                print("❌ No unpaid annuity (registro_nao_ok.gif) found.")
                # Parse the filing date
                filing_date_obj = datetime.strptime(filing_date_raw, '%d/%m/%Y')

                # Add 2 years and 3 months
                due_date_obj = filing_date_obj + relativedelta(years=2, months=3)

                # Format the due date in ISO format
                due_date = f"{due_date_obj.strftime('%Y-%m-%d')}T00:00:00.000Z"

        except NoSuchElementException as e:
            print("Element not found:", e)

        # Check if due_date or filing_date or entity is missing
        if filing_date is None or due_date is None or entity == "":
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "BR",
                "WEB_SCRAPER_STATUS": False
            }      



        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "BR",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "BR",
            "WEB_SCRAPER_STATUS": False
        }
