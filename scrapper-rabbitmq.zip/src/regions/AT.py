from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from seleniumbase import Driver
from datetime import datetime
from datetime import datetime, timezone
import time
from bs4 import BeautifulSoup


# AT Region
def scrape_AT(application_number, template_id):

    # Ensure application number starts with "EP"
    if not application_number.upper().startswith("EP"):
        app_no = "EP" + application_number
    
    # Remove decimal part → keep only number before decimal
    application_number_clean = app_no.replace("EP", "").split('.')[0]

    # Rebuild full application number with EP prefix
    app_no = "EP" + application_number_clean

    # driver = Driver(uc =True)
    driver = Driver(uc =True)
    url = f"https://register.epo.org/application?number={app_no}"
    print(url)
    driver.uc_open_with_reconnect(url, 4)
    # driver.uc_open_with_reconnect(url, 4)

    # region specific logic for AT
    try: 

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        application_number = application_number
        print(f"Searching for: {application_number}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        # Click on Legal Status
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "epoContentNav"))
        )

        # Find and click the "EP Legal status" link
        legal_status_link = driver.find_element(By.XPATH, "//a[contains(text(),'EP Legal status')]")
        print("🔗 Clicking on: EP Legal status")
        legal_status_link.click()

        # Wait 5 seconds on the new page
        print("⏳ Waiting 5 seconds on Legal status page...")
        time.sleep(5)

        # Now click on TR Link
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "ext"))
        )

        # Find the <a> tag with text "TR" and click it
        tr_link = driver.find_element(By.XPATH, "//a[@class='ext' and text()='AT']")
        tr_url = tr_link.get_attribute("href")
        print(f"🔗 Found AT link: {tr_url}")

        # Navigate to the Turkish patent register link
        driver.get(tr_url)

        # Wait on that page for 5 seconds
        print("⏳ Waiting 5 seconds on Austria site...")
        time.sleep(5)

        # Translate Page into English
        try:
            translate_link = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, '//*[@id="mainnav"]/ul/li[1]/a'))
            )
            translate_link.click()
            time.sleep(5)
        except:
            print("⚠️ Navigation tab click not needed or skipped.")

        soup = BeautifulSoup(driver.page_source, 'html.parser')

        # === Individual Field Extractors ===
        def extract_field(label_text):
            label = soup.find("label", string=lambda x: x and label_text in x)
            if label:
                parent_tr = label.find_parent("tr")
                if parent_tr:
                    cells = parent_tr.find_all("td")[1:]
                    return " ".join(cell.get_text(strip=True) for cell in cells).strip()
            return "Not Found"

        # Grant Number
        def extract_grant_number():
            value = extract_field("EP Publication No")
            return f"EP{value}" if value != "Not Found" else value

        # Title
        def extract_title():
            return extract_field("Title")
        
        # Filed By
        def extract_filed_by():
            full_text = extract_field("Applicant")
            return full_text.split(',')[0].strip() if full_text != "Not Found" else full_text


        def format_date(date_str):
            try:
                return datetime.strptime(date_str.strip(), "%d/%m/%Y").strftime("%Y-%m-%dT00:00:00.000Z")
            except:
                return date_str  # Return original if parsing fails

        # International Filing Date
        def extract_filing_date():
            raw = extract_field("Application Date")
            return format_date(raw) if raw != "Not Found" else None

        # Grant Date
        def extract_grant_date():
            raw = extract_field("EP Grant Date")
            return format_date(raw) if raw != "Not Found" else None

        # Due Date
        def extract_due_date():
            raw = extract_field("Next due date")
            return format_date(raw) if raw != "Not Found" else None
        
        # Lawyer
        def extract_lawyer():
            return extract_field("Representative")
        
        # Status
        def extract_status():
            return extract_field("State")


        grant_number = extract_grant_number()
        title =  extract_title()
        filled_by_text = extract_filed_by()
        filing_date = extract_filing_date()
        grant_date = extract_grant_date()
        due_date = extract_due_date()
        lawyer = extract_lawyer()
        status = extract_status()

        entity = ""
        DE_number = ""
        application_type = ""
        google_site = ""

        # Extracting the current URL
        PTO_site = driver.current_url

        # ✅ Close the driver once scraping is done
        driver.quit()

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "AT",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        try:
            driver.quit()  # Make sure driver still closes on error
        except:
            pass
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "AT",
            "WEB_SCRAPER_STATUS": False
        }