from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from dateutil.relativedelta import relativedelta
from seleniumbase import Driver
from datetime import datetime, timezone
import time
from bs4 import BeautifulSoup
import calendar
import re


# Grrece Region
def scrape_GR(application_number, template_id):

    # Ensure application number starts with "EP"
    if not application_number.upper().startswith("EP"):
        app_no = "EP" + application_number
    
    # Remove decimal part → keep only number before decimal
    application_number_clean = app_no.replace("EP", "").split('.')[0]

    # Rebuild full application number with EP prefix
    app_no = "EP" + application_number_clean

    driver = Driver(uc =True)
    url = f"https://register.epo.org/application?number={app_no}"
    print(url)
    driver.uc_open_with_reconnect(url, 4)

    # region specific logic for GR
    try: 
        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        application_number = application_number
        print(f"Searching for: {application_number}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        # Click on Legal Status
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "epoContentNav"))
        )

        # Find and click the "EP Legal status" link
        legal_status_link = driver.find_element(By.XPATH, "//a[contains(text(),'EP Legal status')]")
        print("🔗 Clicking on: EP Legal status")
        legal_status_link.click()

        # Wait 5 seconds on the new page
        print("⏳ Waiting 5 seconds on Legal status page...")
        time.sleep(5)

        # Now click on GR Link
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "ext"))
        )

        # Find the <a> tag with text "GR" and click it
        tr_link = driver.find_element(By.XPATH, "//a[@class='ext' and text()='GR']")
        tr_url = tr_link.get_attribute("href")
        print(f"🔗 Found GR link: {tr_url}")

        # Navigate to the Grrece patent register link
        driver.get(tr_url)

        # Wait on that page for 5 seconds
        print("⏳ Waiting 5 seconds on Greek site...")
        time.sleep(5)

        # Function to convert DD/MM/YYYY → YYYY-MM-DDT00:00:00.000Z
        def format_date_iso(date_str):
            try:
                return datetime.strptime(date_str.strip(), "%d/%m/%Y").strftime("%Y-%m-%dT00:00:00.000Z")
            except:
                return None

        soup = BeautifulSoup(driver.page_source, "html.parser")

        # Initialize variables
        title = None
        grant_number = None
        filled_by_text = None
        filing_date = None
        grant_date = None
        lawyer = None

        # 1. Extract Title
        title_span = soup.find("span", id="dnn_UcEMTWrapper1_ctl00_lblTitle")
        if title_span:
            title = title_span.get_text(strip=True)

        # 2. Extract Grant Number & Grant Date
        epo_grant_row = soup.find("span", id="dnn_UcEMTWrapper1_ctl00_lblEPOPublNumberDate_")
        if epo_grant_row:
            parts = epo_grant_row.get_text(strip=True).split(" - ")
            if len(parts) == 2:
                grant_number = "EP" + parts[0].strip()  # prefix with "EP"
                grant_date = format_date_iso(parts[1].strip())

        # 3. Extract Filing Date
        epo_app_row = soup.find("span", id="dnn_UcEMTWrapper1_ctl00_lblEPOApplNumberDate_")
        if epo_app_row:
            parts = epo_app_row.get_text(strip=True).split(" - ")
            if len(parts) == 2:
                filing_date = format_date_iso(parts[1].strip())

        # 4. Extract Filled By (Applicant) from Owners table
        owners_table = soup.find("table", id="dnn_UcEMTWrapper1_ctl00_gvOwners")
        if owners_table:
            first_row = owners_table.find_all("tr")[1]  # skip header
            cols = first_row.find_all("td")
            if len(cols) >= 3:
                filled_by_text = cols[2].get_text(strip=True)

        # 5. Extract Lawyer from Representatives table
        reps_table = soup.find("table", id="dnn_UcEMTWrapper1_ctl00_gvRepresentatives")
        if reps_table:
            first_row = reps_table.find_all("tr")[1]  # skip header
            cols = first_row.find_all("td")
            if len(cols) >= 3:
                lawyer = cols[2].get_text(strip=True)

        # Extract Legal Status
        status_span = soup.find("span", id="dnn_UcEMTWrapper1_ctl00_lblLegalStatus_")
        status = status_span.get_text(strip=True) if status_span else None

        # Due Date Calculation

        # Find the fieldset with legend containing "Payments history"
        fieldset = None
        for fs in soup.find_all("fieldset"):
            legend = fs.find("legend")
            if legend and "Payments history" in legend.get_text(strip=True):
                fieldset = fs
                break

        # Proceed if correct fieldset found
        renewal_years = None
        due_date = None

        if fieldset:
            renewal_text = fieldset.get_text(strip=True)
            print("Renewal Text:", renewal_text)

            match = re.search(r"(\d+)\s+renewals", renewal_text, re.IGNORECASE)
            if match:
                renewal_years = int(match.group(1))

        if renewal_years is not None:
            filing_dt = datetime.strptime(filing_date, "%Y-%m-%dT00:00:00.000Z")
            target_year = filing_dt.year + renewal_years
            target_month = filing_dt.month
            last_day = calendar.monthrange(target_year, target_month)[1]
            due_dt = datetime(target_year, target_month, last_day)
            due_date = due_dt.strftime("%Y-%m-%dT00:00:00.000Z")

        print("✅ Due Date based on renewals:", due_date)

        entity = ""
        DE_number = ""
        application_type = ""
        google_site = ""
        

        # Extracting the current URL
        PTO_site = driver.current_url

        # ✅ Close the driver once scraping is done
        driver.quit()

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "GR",
            "granT_NUMBER": grant_number,
            "title" : title,
            "entity_size": entity,
            "fileD_BY": filled_by_text,
            "international_filing_date": filing_date,
            "grant_date": grant_date,
            "due_date": due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        try:
            driver.quit()  # Make sure driver still closes on error
        except:
            pass
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "GR",
            "WEB_SCRAPER_STATUS": False
        }