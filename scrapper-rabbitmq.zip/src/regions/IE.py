from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from dateutil.relativedelta import relativedelta
from datetime import datetime
from datetime import datetime, timezone
import time


# Ireland Region
def scrape_IE(driver, application_number, template_id):

    url = f"https://eregister.ipoi.gov.ie/register/PTRegister.aspx?idappli={application_number}"
    driver.get(url)

    # region specific logic for IE
    try: 

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        application_number = application_number
        print(f"Searching for: {application_number}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        #grant number
        try:    
            grant_element = driver.find_element(By.XPATH, "//td[@headers='grantnumber']/a")
            grant_number_raw = grant_element.text.strip()
            grant_number = f"EP{grant_number_raw}"
            print(grant_number)

        except NoSuchElementException:
            grant_number = ""
        
        #title
        try:    
            title_element = driver.find_element(By.XPATH, "//td[@headers='TitleOfInvention']/strong")
            title = title_element.text.strip()
            print(title)

        except NoSuchElementException:
            title = ""
        
        # Filed By
        try:
            filed_by_element = driver.find_element(By.XPATH, "//td[@headers='inventors']/strong")
            filled_by_text = filed_by_element.text.strip()
            print(filled_by_text)
        except NoSuchElementException:
            filled_by_text = ""
        
        # International Filing Date
        try:    
            international_filing_date_element = driver.find_element(By.XPATH, "//td[@headers='dateOfFiling']")
            international_filing_date_raw = international_filing_date_element.text.strip()
            filing_date_dt = datetime.strptime(international_filing_date_raw, "%d/%m/%Y")
            filing_date = filing_date_dt.strftime("%Y-%m-%d") + "T00:00:00.000Z"
        except NoSuchElementException:
            filing_date = None
            filing_date_dt = None
        
        # Grant Date
        try:    
            grant_date_element = driver.find_element(By.XPATH, "//td[@headers='sealingDate']")
            grant_date_raw = grant_date_element.text.strip()
            grant_date = datetime.strptime(grant_date_raw, "%d/%m/%Y").strftime("%Y-%m-%d") + "T00:00:00.000Z"
            print(grant_date)

        except NoSuchElementException:
            grant_date = None

        # Due Date
        try:    
            renewal_year_value = driver.find_element(By.XPATH, "//td[@headers='renewalFees']//table//tr[2]/td[1]").text.strip()
            renewal_year = int(renewal_year_value)
        except:
            renewal_year = None

        # Calculate Due Date by adding renewal_year
        try:
            if filing_date_dt and renewal_year:
                due_date_raw = filing_date_dt + relativedelta(years=renewal_year)
                due_date = due_date_raw.strftime("%Y-%m-%dT00:00:00.000Z")
            else:
                due_date = None
        except:
            due_date = None

        #lawyer
        try:    
            lawyer_element = driver.find_element(By.XPATH, '//*[@id="tblPT"]/tbody/tr[9]/td/strong')
            lawyer = lawyer_element.text.strip()
            print(lawyer)

        except NoSuchElementException:
            lawyer = ""
        

        DE_number = ""

        #Status
        try:    
            status_element = driver.find_element(By.XPATH, "//td[@headers='status']")
            status = status_element.text.strip()
            print(status)

        except NoSuchElementException:
            status = ""
         
        entity = "" 
        application_type = ""
        google_site = ""

        # Extracting the current URL
        PTO_site = driver.current_url

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "IE",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "IE",
            "WEB_SCRAPER_STATUS": False
        }