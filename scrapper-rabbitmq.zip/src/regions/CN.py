from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime
from datetime import datetime, timezone
import re

def scrape_CN(driver, application_number, template_id):
    url = f"https://patents.google.com/patent/CN115697827A/en?oq={application_number}"
    driver.get(url)

    try:
        print(f"Searching for: {application_number}")
        print("-" * 20)

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        
        #application number extraction
        try:
            application_number_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="wrapper"]/div[1]/div[2]/section/application-timeline/div/div[3]'))
            )
            application_number = application_number_element.text.strip()
            match = re.search(r'CN(\d+\.\d+)', application_number)
            if match:
                application_number = match.group(1)
        except NoSuchElementException:
            application_number = ""


        #grant number extraction
        try:
            grant_number_element = driver.find_element(By.XPATH, '//*[@id="pubnum"]')
            grant_number = grant_number_element.text.strip()

        except NoSuchElementException:
            grant_number = ""


        #title extraction
        try:
            full_title = driver.execute_script('return document.title;')
            

            # Extract only the part after the hyphen (assuming the title format is consistent)
            title_parts = full_title.split(' - ')
            if len(title_parts) > 1:
                title = title_parts[1].strip() 
            else:
                title = full_title.strip()

        except NoSuchElementException:
            title = ""
        
        
        entity = "Large"

        # filled by
        try:
            filed_by_raw = driver.find_element(By.XPATH, "//span[contains(text(), 'Application filed by')]")
            filled_by_text = filed_by_raw.text.replace("Application filed by ", "").strip()
        except NoSuchElementException:
            filled_by_text = ""
        


        # international filing date
        try:
            container = filed_by_raw.find_element(By.XPATH, "./ancestor::div[contains(@class, 'event')]")

            # Now get the date inside that container
            filing_date_raw = container.find_element(By.XPATH, ".//div[contains(@class, 'filed')]").text.strip()

            try:
                # Try parsing common formats
                try:
                    date_obj = f"{datetime.strptime(filing_date_raw, '%d %b %Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
                except ValueError:
                    date_obj = f"{datetime.strptime(filing_date_raw, '%Y-%m-%d').strftime('%Y-%m-%d')}T00:00:00.000Z"

                filing_date = date_obj

            except ValueError as e:
                print(f"Date parsing error: {e}")
                filing_date = None

        except NoSuchElementException:
            filing_date = None


        # grant date
        try:
            check_granted = driver.find_element(By.XPATH, "//span[contains(text(), 'Application') and contains(text(), 'granted')]")
            if "not granted" not in check_granted.text.lower():
                grant_date_element = check_granted.find_element(By.XPATH, "./ancestor::div[contains(@class, 'event')]")
                grant_date_raw = grant_date_element .find_element(By.XPATH, ".//div[contains(@class, 'granted')]").text.strip()

                # Try parsing different date formats
                try:
                    date_obj = f"{datetime.strptime(grant_date_raw, '%d %b %Y').strftime('%Y-%m-%d')}T00:00:00.000Z"
                except ValueError:
                    date_obj = f"{datetime.strptime(grant_date_raw, '%Y-%m-%d').strftime('%Y-%m-%d')}T00:00:00.000Z"
                
                grant_date = date_obj

            else:
                grant_date = None

        except NoSuchElementException:
            grant_date = None


        
        #Due date calculation
        due_date = None

        filing_date_str = datetime.strptime(filing_date, "%Y-%m-%dT%H:%M:%S.%fZ")
        today = datetime.today()

        # Try using the current year for the anniversary
        due_date_raw = filing_date_str.replace(year=today.year)

        # If that date is in the past, use next year
        if due_date_raw < today:
            due_date_raw = filing_date_str.replace(year=today.year + 1)

        # Format the due date in ISO format
        due_date = f"{due_date_raw.strftime('%Y-%m-%d')}T00:00:00.000Z"



        DE_number = ""
        lawyer = ""
        
    
        #status
        try:
            status_element = driver.find_element(By.XPATH, "//div[contains(translate(text(), 'STATUS', 'status'), 'status')]/following-sibling::div/span[@class='title-text style-scope application-timeline']")
            status = status_element.text.strip()

        except NoSuchElementException:
            status = ""
         

        application_type = ""
        google_site =driver.current_url
        PTO_site = ""

        # Check if due_date or filing_date or entity is missing
        if filing_date is None or due_date is None:
            return {
                "templatE_REQUEST_UPLOAD_ID": template_id,
                "applicatioN_NUMBER": application_number,
                "countrY_ISO2_CODE": "CN",
                "WEB_SCRAPER_STATUS": False
            }

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "CN",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "CN",
            "WEB_SCRAPER_STATUS": False
        }