from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime
from datetime import datetime, timezone
import time


# Switzerland Region
def scrape_CH(driver, application_number, template_id):

    # Ensure application number starts with "EP"
    if not application_number.upper().startswith("EP"):
        application_number = "EP" + application_number
    
    # Remove decimal part → keep only number before decimal
    application_number_clean = application_number.replace("EP", "").split('.')[0]

    # Rebuild full application number with EP prefix
    application_number = "EP" + application_number_clean

    url = f"https://www.swissreg.ch/database-client/register/detail?type=patent&lang=en&no={application_number}"
    driver.get(url)    

    # region-specific scraping logic for CH
    try:        
        input_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="cdk-accordion-child-0"]/div/div/div/div[1]/swr-detail-definition-list[4]/dl/dd/span'))
        )
        application_number = input_element.text.strip()

        when_run = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')
        application_number = application_number
        print(f"Searching for: {application_number}")
        print("-" * 20)

        # Wait for result page to load
        time.sleep(3)

        #grant
        try:    
            grant_element = driver.find_element(By.XPATH, '//*[@id="cdk-accordion-child-0"]/div/div/div/div[1]/swr-detail-definition-list[5]/dl/dd/span')
            grant_number = grant_element.text.strip()

        except NoSuchElementException:
            grant_number = ""
        
        #title
        try:    
            title_element = driver.find_element(By.XPATH, '/html/body/swr-root/ipi-app-container/div/mat-sidenav-container/mat-sidenav-content/main/swr-register-detail-container/div/div[2]/swr-patent-detail/div/div[1]/swr-schutztitel-detail-title/div/div/dl/dd/egov-page-title/div/div/div/h1/span')
            title_raw_text = title_element.text.strip()

            # 2️⃣ Save current SwissReg URL
            PTO_site = driver.current_url

            # 3️⃣ Go to Google Translate and translate the title
            driver.get("https://translate.google.co.in/?sl=auto&tl=en&op=translate")

            # Wait for input box
            input_box = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, 'textarea.er8xn'))
            )
            input_box.clear()
            input_box.send_keys(title_raw_text)
            input_box.send_keys(Keys.ENTER)

            # Wait for translated text
            translated_box = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, 'span.ryNqvb[jsname="W297wb"]'))
            )
            title = translated_box.text.strip().upper()
            print(f"Title translated: {title}")

            # 4️⃣ Go back to SwissReg page
            driver.get(PTO_site)
            time.sleep(3)  # wait for page to reload fully before continuing
            
        except NoSuchElementException:
            title = ""
        
        entity = ""

        #filled by
        try:    
            filled_by_element = driver.find_element(By.XPATH, '//*[@id="cdk-accordion-child-2"]/div/div/swr-registeradresse-card-list-entry/div/ul/li/egov-address-display/div/div[1]/span')
            filled_by_text = filled_by_element.text.strip()

        except NoSuchElementException:
            filled_by_text = ""

        #international filing date
        try:
            filing_date_element = driver.find_element(By.XPATH, '//*[@id="cdk-accordion-child-0"]/div/div/div/div[2]/swr-detail-definition-list[1]/dl/dd/span')
            filing_date_raw = filing_date_element.text.strip()

            # Reformat date: "28/12/2016" → "2016-12-28"
            filing_date_parsed = datetime.strptime(filing_date_raw, "%d.%m.%Y")
            filing_date = filing_date_parsed.strftime("%Y-%m-%d") + "T00:00:00.000Z"

        except NoSuchElementException:
            filing_date = None

        #grant date
        try:    
            grant_date_element = driver.find_element(By.XPATH, '//*[@id="cdk-accordion-child-0"]/div/div/div/div[2]/swr-detail-definition-list[3]/dl/dd/span')
            grant_date_raw = grant_date_element.text.strip()

            # Reformat date: "28/12/2016" → "2016-12-28"
            grant_date_parsed = datetime.strptime(grant_date_raw, "%d.%m.%Y")
            grant_date = grant_date_parsed.strftime("%Y-%m-%d") + "T00:00:00.000Z"

        except NoSuchElementException:
            grant_date = None

        #due date
        try:    
            due_date_element = driver.find_element(By.XPATH, '//*[@id="cdk-accordion-child-0"]/div/div/div/div[2]/swr-detail-definition-list[4]/dl/dd/span')
            due_date_raw = due_date_element.text.strip()

            # Reformat date: "28/12/2016" → "2016-12-28"
            due_date_parsed = datetime.strptime(due_date_raw, "%d.%m.%Y")
            due_date = due_date_parsed.strftime("%Y-%m-%d") + "T00:00:00.000Z"

        except NoSuchElementException:
            due_date = None
        

        #lawyer
        lawyer = ""
        DE_number = ""

        #status
        try:
            status_element = driver.find_element(By.XPATH, '//*[@id="cdk-accordion-child-0"]/div/div/div/div[1]/swr-detail-definition-list[1]/dl/dd/ipi-schutztitelstatus/span/span')
            status = status_element.text.strip()
        except NoSuchElementException:
            status = ""
         
        application_type = ""
        google_site = ""

        # Extracting the current URL
        PTO_site = driver.current_url

        # Final Application Number
        application_number = application_number.replace("EP", "").strip()

        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "CH",
            "granT_NUMBER": grant_number,
            "title": title,
            "entitY_SIZE": entity,
            "fileD_BY": filled_by_text,
            "internationaL_FILING_DATE": filing_date,
            "granT_DATE": grant_date,
            "duE_DATE" : due_date,
            "lawyer": lawyer,
            "dE_NUMBER": DE_number,
            "patenT_APPLICATION_STATUS": status,
            "applicatioN_TYPE_NAME": application_type,
            "googlE_SITE": google_site,
            "ptO_SITE": PTO_site,
            "WEB_SCRAPER_STATUS": True
        }


    except Exception as e:
        print(f"Error occurred: {e}")
        return {
            "templatE_REQUEST_UPLOAD_ID": template_id,
            "wheN_RUN": when_run,
            "applicatioN_NUMBER": application_number,
            "countrY_ISO2_CODE": "CH",
            "WEB_SCRAPER_STATUS": False
        }
