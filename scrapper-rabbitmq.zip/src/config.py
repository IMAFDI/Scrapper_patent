from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # Existing settings
    RABBIT_URL: str = "amqp://guest:guest@localhost:5672/"
    QUEUE_REQ: str = "scrapper.requests"
    QUEUE_RESP: str = "scrapper.responses"
    RESULTS_PATH: str = "scrape_results.json"
    
    # RabbitMQ specific settings
    RABBITMQ_HOST: str = "localhost"
    RABBITMQ_PORT: int = 5672
    RABBITMQ_USER: str = "guest"
    RABBITMQ_PASSWORD: str = "guest"
    RABBITMQ_VHOST: str = "/"
    
    # Add the missing AUTO_PROCESS field
    AUTO_PROCESS: str = "true"
    
    # Environment and API settings
    ENVIRONMENT: str = "production"
    API_KEY: str = "your-secret-api-key"
    
    class Config:
        env_file = ".env"
        extra = "ignore"  

settings = Settings()