import asyncio
import json
import logging
from typing import Optional, Callable
import aio_pika
from aio_pika import connect, Message, ExchangeType
from aio_pika.abc import AbstractConnection, AbstractChannel, AbstractQueue, AbstractIncomingMessage
from config import settings

logger = logging.getLogger(__name__)

class RabbitMQManager:
    def __init__(self):
        self.connection: Optional[AbstractConnection] = None
        self.channel: Optional[AbstractChannel] = None
        self.request_queue: Optional[AbstractQueue] = None
        self.response_queue: Optional[AbstractQueue] = None
        self.consumer_tag: Optional[str] = None
    
    async def connect(self):
        """Establish connection to RabbitMQ"""
        try:
            self.connection = await connect(settings.RABBIT_URL)
            self.channel = await self.connection.channel()
            await self.channel.set_qos(prefetch_count=1)
            logger.info("Connected to RabbitMQ successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to RabbitMQ: {e}")
            return False
    
    async def setup_queues(self):
        """Declare and setup queues"""
        if not self.channel:
            raise RuntimeError("Channel not initialized. Call connect() first.")
        
        # Declare request queue
        self.request_queue = await self.channel.declare_queue(
            settings.QUEUE_REQ,
            durable=True
        )
        
        # Declare response queue
        self.response_queue = await self.channel.declare_queue(
            settings.QUEUE_RESP,
            durable=True
        )
        
        logger.info(f"Queues declared: {settings.QUEUE_REQ}, {settings.QUEUE_RESP}")
    
    async def publish_message(self, queue_name: str, message: dict):
        """Publish a message to a queue"""
        if not self.channel:
            raise RuntimeError("Channel not initialized. Call connect() first.")
        
        try:
            message_body = json.dumps(message).encode()
            await self.channel.default_exchange.publish(
                Message(
                    message_body,
                    delivery_mode=aio_pika.DeliveryMode.PERSISTENT
                ),
                routing_key=queue_name
            )
            logger.info(f"Message published to {queue_name}")
        except Exception as e:
            logger.error(f"Failed to publish message to {queue_name}: {e}")
            raise
    
    async def start_consumer(self, message_handler: Callable):
        """Start consuming messages from the request queue"""
        if not self.request_queue:
            raise RuntimeError("Request queue not initialized. Call setup_queues() first.")
        
        try:
            # Start consuming messages
            await self.request_queue.consume(message_handler)
            logger.info(f"Started consuming messages from {settings.QUEUE_REQ}")
        except Exception as e:
            logger.error(f"Failed to start consumer: {e}")
            raise
    
    async def stop_consumer(self):
        """Stop consuming messages"""
        if self.consumer_tag and self.channel:
            try:
                await self.channel.cancel(self.consumer_tag)
                logger.info("Consumer stopped")
            except Exception as e:
                logger.error(f"Error stopping consumer: {e}")
    
    async def close(self):
        """Close connection"""
        await self.stop_consumer()
        if self.connection and not self.connection.is_closed:
            await self.connection.close()
            logger.info("RabbitMQ connection closed")
    
    async def health_check(self) -> bool:
        """Check if RabbitMQ connection is healthy"""
        try:
            if self.connection and not self.connection.is_closed:
                return True
            return False
        except Exception:
            return False

# Global instance
rabbitmq_manager = RabbitMQManager()