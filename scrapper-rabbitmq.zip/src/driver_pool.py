from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from fake_useragent import UserAgent
import os


def _add_fake_user_agent(options: Options) -> None:
    """Attach a random Userâ€‘Agent string to evade basic blocking."""
    ua = UserAgent()
    options.add_argument(f"user-agent={ua.random}")


def initialize_driver() -> webdriver.Chrome:
    """
    Build and return a configured Chrome WebDriver.
    â€¢ Headless mode is ON by default.
    â€¢ Toggle with environment variable:  HEADLESS=false
    """
    options = Options()

    # Headless toggle
    headless = os.getenv("HEADLESS", "true").lower() == "true"
    if headless:
        options.add_argument("--headless=new")      # Chrome â‰¥118
    # Hardening / CI flags
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")

    _add_fake_user_agent(options)
    return webdriver.Chrome(options=options)