import asyncio
import json
import logging
import os
from typing import List, Dict, Any
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from config import settings
from rabbitmq_manager import rabbitmq_manager
from message_processor import message_processor
from scraper import scrape_data
from annuity_api import annuity_client

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment configuration
ENVIRONMENT = os.getenv("ENVIRONMENT", "production")
API_KEY = os.getenv("API_KEY", "123456789")

# Security
security = HTTPBearer()

async def verify_api_key(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Verify API key for protected endpoints"""
    if credentials.credentials != API_KEY:
        raise HTTPException(
            status_code=401,
            detail="Invalid API key",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return credentials.credentials

# Annuity API configuration
ANNUITY_BASE_URL = os.getenv("API_BASE_URL", "https://annuitybe.mintwaystech.in/api")
ANNUITY_EMAIL = os.getenv("LOGIN_EMAIL", "system")
ANNUITY_PASSWORD = os.getenv("LOGIN_PASSWORD", "P@ssw0rd4321")

# Pydantic models
class HealthResponse(BaseModel):
    status: str
    rabbitmq: str
    queues: Dict[str, str]
    timestamp: str

class SystemStatusResponse(BaseModel):
    connected: bool
    host: str
    port: int
    queues: Dict[str, str]
    timestamp: str

class ResultsResponse(BaseModel):
    count: int
    results: List[Dict[str, Any]]
    timestamp: str

class ResultsCountResponse(BaseModel):
    count: int
    timestamp: str

# ============ PAYLOAD LOADER now from ANNUITY API ONLY ==========
async def auto_process_default_payload():
    """Fetch applications from Annuity API and publish to RabbitMQ request queue on startup."""
    try:
        await asyncio.sleep(2)
        payload = await annuity_client.get_payload()
        # If payload is dict with 'data' key (as expected from API)
        if isinstance(payload, dict) and "data" in payload:
            payload = payload["data"]

        if payload:
            logger.info(f"Auto-processing {len(payload)} items from Annuity API")
            for item in payload:
                app_no = item.get("applicatioN_NUMBER", "") or item.get("application_number", "")
                country = item.get("countrY_ISO2_CODE", "") or item.get("country_code", "")
                template_id = item.get("templatE_REQUEST_UPLOAD_ID", "") or item.get("id", "")
                if app_no and country and template_id:
                    message_data = {
                        "app_no": app_no,
                        "country": country,
                        "template_id": template_id
                    }
                    await rabbitmq_manager.publish_message(settings.QUEUE_REQ, message_data)
                    logger.info(f"Auto-published: {app_no} ({country})")
                    await asyncio.sleep(0.5)
            logger.info("Auto-processing completed successfully")
        else:
            logger.warning("No application data found from Annuity API.")
    except Exception as e:
        logger.error(f"Error in auto-processing: {e}")

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    logger.info(f"Starting up patent scrapping service...")
    connected = await rabbitmq_manager.connect()
    if connected:
        await rabbitmq_manager.setup_queues()
        await rabbitmq_manager.start_consumer(message_processor.handle_message)
        logger.info("RabbitMQ setup completed and consumer started")
        # Payload from Annuity API only:
        if os.getenv("AUTO_PROCESS", "true").lower() == "true":
            await auto_process_default_payload()
    else:
        logger.error("Failed to connect to RabbitMQ - service will run in degraded mode")
    yield
    logger.info("Shutting down patent scrapping service...")
    await rabbitmq_manager.close()

app = FastAPI(
    title="Patent Scrapping Service",
    description="Production-ready microservice for scraping patent data",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if ENVIRONMENT == "development" else [],
    allow_credentials=True,
    allow_methods=["GET"],
    allow_headers=["*"],
)

# File loader is still here if needed for existing endpoints (but NOT used for payload processing)
def load_json_file(file_path: str) -> List[Dict[str, Any]]:
    """Load JSON file and return data"""
    try:
        with open(file_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        logger.error(f"File {file_path} not found")
        return []
    except json.JSONDecodeError as e:
        logger.error(f"Error parsing JSON file {file_path}: {e}")
        return []

# ============= ESSENTIAL ENDPOINTS ONLY ==================

@app.get("/health", response_model=HealthResponse)
async def health_check():
    rabbitmq_healthy = await rabbitmq_manager.health_check()
    return HealthResponse(
        status="healthy" if rabbitmq_healthy else "degraded",
        rabbitmq="connected" if rabbitmq_healthy else "disconnected",
        queues={
            "requests": settings.QUEUE_REQ,
            "responses": settings.QUEUE_RESP
        },
        timestamp=datetime.now().isoformat()
    )

@app.get("/status", response_model=SystemStatusResponse)
async def system_status():
    is_healthy = await rabbitmq_manager.health_check()
    return SystemStatusResponse(
        connected=is_healthy,
        host=settings.RABBITMQ_HOST,
        port=settings.RABBITMQ_PORT,
        queues={
            "request_queue": settings.QUEUE_REQ,
            "response_queue": settings.QUEUE_RESP
        },
        timestamp=datetime.now().isoformat()
    )

@app.get("/results/count", response_model=ResultsCountResponse)
async def get_results_count():
    results = load_json_file(settings.RESULTS_PATH)
    return ResultsCountResponse(
        count=len(results),
        timestamp=datetime.now().isoformat()
    )

@app.get("/results", response_model=ResultsResponse)
async def get_results(api_key: str = Depends(verify_api_key)):
    results = load_json_file(settings.RESULTS_PATH)
    if not results:
        raise HTTPException(status_code=404, detail="No results found")
    return ResultsResponse(
        count=len(results),
        results=results,
        timestamp=datetime.now().isoformat()
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)